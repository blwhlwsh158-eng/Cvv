package com.example.service

import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import android.util.Log
import com.example.utils.ArabicPrinterHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.io.OutputStream
import java.nio.charset.Charset
import java.util.UUID

class BluetoothPrintService : Service() {

    companion object {
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val TAG = "BluetoothPrintService"
    }

    private val binder = LocalBinder()
    private val scope = CoroutineScope(Dispatchers.Main)
    private var bluetoothSocket: BluetoothSocket? = null
    
    // Printer State
    val isConnected = MutableStateFlow(false)
    val isConnecting = MutableStateFlow(false)
    val connectionStatus = MutableStateFlow("غير متصل")

    private val bluetoothAdapter: BluetoothAdapter? by lazy {
        BluetoothAdapter.getDefaultAdapter()
    }

    inner class LocalBinder : Binder() {
        fun getService(): BluetoothPrintService = this@BluetoothPrintService
    }

    override fun onBind(intent: Intent?): IBinder {
        Log.d(TAG, "Service bound")
        return binder
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "Service started")
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        disconnect()
        Log.d(TAG, "Service destroyed")
    }

    // ==========================================
    // SOCKET CONNECTION METHODS (BACKGROUND THREAD)
    // ==========================================
    fun connectDevice(macAddress: String, printerName: String, onResult: (Boolean, String) -> Unit = { _, _ -> }) {
        val adapter = bluetoothAdapter
        if (adapter == null || !adapter.isEnabled) {
            onResult(false, "البلوتوث غير مفعّل أو غير مدعوم")
            return
        }

        scope.launch {
            isConnecting.value = true
            connectionStatus.value = "جاري الاتصال بـ $printerName..."
            
            val success = withContext(Dispatchers.IO) {
                try {
                    closeSocketInternal()
                    val device = adapter.getRemoteDevice(macAddress)
                    val socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                    socket.connect()
                    bluetoothSocket = socket
                    true
                } catch (e: Exception) {
                    Log.e(TAG, "Connection failed to $macAddress", e)
                    false
                }
            }

            isConnecting.value = false
            if (success) {
                isConnected.value = true
                connectionStatus.value = "متصل بـ $printerName"
                onResult(true, "تم الاتصال بنجاح!")
            } else {
                isConnected.value = false
                connectionStatus.value = "فشل الاتصال"
                bluetoothSocket = null
                onResult(false, "فشل الاتصال بالطابعة")
            }
        }
    }

    fun disconnect() {
        scope.launch {
            withContext(Dispatchers.IO) {
                closeSocketInternal()
            }
            isConnected.value = false
            connectionStatus.value = "غير متصل"
        }
    }

    private fun closeSocketInternal() {
        try {
            bluetoothSocket?.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error closing Bluetooth socket", e)
        } finally {
            bluetoothSocket = null
        }
    }

    // ==========================================
    // ESC/POS AND WRITE OPERATIONS (BACKGROUND THREAD)
    // ==========================================
    fun writeBytes(bytes: ByteArray): Boolean {
        val socket = bluetoothSocket
        if (socket == null || !isConnected.value) {
            Log.e(TAG, "Cannot write bytes: No active socket or not connected")
            return false
        }
        return try {
            val os: OutputStream = socket.outputStream
            os.write(bytes)
            os.flush()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error writing bytes to printer socket", e)
            isConnected.value = false
            connectionStatus.value = "انقطع الاتصال"
            closeSocketInternal()
            false
        }
    }

    fun initializePrinter() {
        writeBytes(byteArrayOf(0x1B, 0x40)) // ESC @
    }

    fun selectCodepageCP1256() {
        writeBytes(byteArrayOf(0x1B, 0x74, 0x16)) // ESC t 22 (Arabic/Windows-1256)
    }

    fun setAlignment(align: Int) {
        // n = 0: Left, n = 1: Center, n = 2: Right
        writeBytes(byteArrayOf(0x1B, 0x61, align.toByte()))
    }

    fun setTextSize(doubleSize: Boolean) {
        if (doubleSize) {
            writeBytes(byteArrayOf(0x1D, 0x21, 0x11)) // GS ! 17 (Double height + Double width)
        } else {
            writeBytes(byteArrayOf(0x1D, 0x21, 0x00)) // GS ! 0 (Normal size)
        }
    }

    fun setBold(isBold: Boolean) {
        if (isBold) {
            writeBytes(byteArrayOf(0x1B, 0x45, 0x01)) // ESC E 1 (Bold on)
        } else {
            writeBytes(byteArrayOf(0x1B, 0x45, 0x00)) // ESC E 0 (Bold off)
        }
    }

    fun feedPaper(lines: Int = 4) {
        writeBytes(byteArrayOf(0x1B, 0x64, lines.toByte())) // ESC d lines
    }

    fun cutPaper() {
        writeBytes(byteArrayOf(0x1D, 0x56, 0x41, 0x00)) // GS V A 0 (Full/Half cut paper)
    }

    fun printRawText(text: String, align: Int = 0, doubleSize: Boolean = false, isBold: Boolean = false, codepage: String = "CP1256") {
        setAlignment(align)
        setTextSize(doubleSize)
        setBold(isBold)

        val formattedText = text + "\n"
        try {
            val bytes = if (codepage == "UTF-8") {
                formattedText.toByteArray(Charsets.UTF_8)
            } else {
                formattedText.toByteArray(Charset.forName("windows-1256"))
            }
            writeBytes(bytes)
        } catch (e: Exception) {
            Log.e(TAG, "Error translating text to bytes", e)
        }
    }
}
