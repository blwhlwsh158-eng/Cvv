package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import java.text.DecimalFormat

// Helper for Arabic formatting of money
object Formatter {
    private val decimalFormat = java.text.DecimalFormat("#,###", java.text.DecimalFormatSymbols(java.util.Locale.US))
    
    fun convertArabicToEnglishDigits(input: String): String {
        var result = input
        val arabicDigits = arrayOf("٠", "١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩")
        for (i in 0..9) {
            result = result.replace(arabicDigits[i], i.toString())
        }
        return result
    }
    
    fun formatCurrency(amount: Double): String {
        return "${decimalFormat.format(amount)} د.ع"
    }

    fun formatNumber(amount: Double): String {
        return decimalFormat.format(amount)
    }

    fun sanitizeAmount(input: String): Double {
        val engInput = convertArabicToEnglishDigits(input)
        val clean = engInput.filter { it.isDigit() || it == '.' }
        return clean.toDoubleOrNull() ?: 0.0
    }

    fun updatePriceField(oldValue: String, newValue: String): String {
        val engNewValue = convertArabicToEnglishDigits(newValue)
        val engOldValue = convertArabicToEnglishDigits(oldValue)
        
        val oldDigits = engOldValue.filter { it.isDigit() }
        val newDigits = engNewValue.filter { it.isDigit() }
        
        val finalDigits = if (engNewValue.length < engOldValue.length && oldDigits == newDigits && oldDigits.isNotEmpty()) {
            oldDigits.dropLast(1)
        } else {
            newDigits
        }
        
        return finalDigits
    }
}

// Premium Card with Radius 16.dp, soft shadow, light border, and optional click support
@Composable
fun PremiumCard(
    modifier: Modifier = Modifier,
    backgroundColor: Color = SoftSurface,
    borderColor: Color? = null,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .shadow(
                elevation = 2.dp,
                shape = RoundedCornerShape(16.dp),
                clip = false,
                ambientColor = Color(0x02000000),
                spotColor = Color(0x04071D49)
            ).then(
                if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
            ),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        border = BorderStroke(1.dp, borderColor ?: BorderLight.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            content = content
        )
    }
}

// Premium Button with Height 56.dp, Radius 16.dp, Deep Navy background, Golden icon, scale animation
@Composable
fun PremiumButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    isSecondary: Boolean = false,
    enabled: Boolean = true
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(if (isPressed) 0.96f else 1f, label = "buttonScale")

    Button(
        onClick = onClick,
        modifier = modifier
            .height(56.dp)
            .scale(scale),
        interactionSource = interactionSource,
        enabled = enabled,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSecondary) Color.White else DeepNavy,
            contentColor = if (isSecondary) DeepNavy else SoftSurface,
            disabledContainerColor = BorderLight.copy(alpha = 0.5f),
            disabledContentColor = TextSecondary
        ),
        border = if (isSecondary) BorderStroke(1.5.dp, RoyalGold) else null,
        contentPadding = PaddingValues(horizontal = 24.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isSecondary) DeepNavy else RoyalGold,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
            }
            Text(
                text = text,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (isSecondary) DeepNavy else SoftSurface
                )
            )
        }
    }
}

// Premium Text Field with Height 56.dp, Radius 16.dp, gold border on focus, checkmark success
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PremiumTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    modifier: Modifier = Modifier,
    leadingIcon: ImageVector? = null,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    isSuccess: Boolean = false,
    readOnly: Boolean = false,
    trailingIcon: @Composable (() -> Unit)? = null
) {
    var isFocused by remember { mutableStateOf(false) }

    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = if (isFocused) RoyalGold else TextDark
            ),
            modifier = Modifier.padding(bottom = 8.dp)
        )
        
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            placeholder = {
                Text(
                    text = placeholder,
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary),
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Start
                )
            },
            readOnly = readOnly,
            keyboardOptions = keyboardOptions,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .onFocusChanged { isFocused = it.isFocused },
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = RoyalGold,
                unfocusedBorderColor = BorderLight,
                focusedContainerColor = GrayLight.copy(alpha = 0.5f),
                unfocusedContainerColor = GrayLight.copy(alpha = 0.5f),
                cursorColor = RoyalGold
            ),
            textStyle = TextStyle(
                fontFamily = androidx.compose.ui.text.font.FontFamily.SansSerif,
                fontSize = 16.sp,
                textDirection = TextDirection.ContentOrRtl,
                textAlign = TextAlign.Start
            ),
            leadingIcon = leadingIcon?.let {
                {
                    Box(
                        modifier = Modifier
                            .padding(start = 12.dp)
                            .size(36.dp)
                            .background(
                                color = if (isFocused) RoyalGold.copy(alpha = 0.1f) else GrayLight,
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = it,
                            contentDescription = null,
                            tint = if (isFocused) RoyalGold else TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            },
            trailingIcon = when {
                isSuccess -> {
                    {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Success",
                            tint = SuccessGreen,
                            modifier = Modifier.padding(end = 12.dp)
                        )
                    }
                }
                trailingIcon != null -> trailingIcon
                else -> null
            },
            singleLine = true
        )
    }
}

// Icon wrapper (Outlined Rounded Symbols placed inside small circles)
@Composable
fun PremiumIconWrapper(
    icon: ImageVector,
    modifier: Modifier = Modifier,
    tint: Color = DeepNavy,
    backgroundColor: Color = GrayLight,
    size: Int = 40
) {
    Box(
        modifier = modifier
            .size(size.dp)
            .background(color = backgroundColor, shape = CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = tint,
            modifier = Modifier.size((size * 0.55).dp)
        )
    }
}

// Floating Premium Navigation Bar with Rounded Elements
@Composable
fun PremiumFloatingNavigationBar(
    selectedItem: Int,
    onItemSelected: (Int) -> Unit,
    items: List<NavigationItem>
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Floating bar with white background, subtle border, and soft shadow
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(76.dp)
                .shadow(
                    elevation = 4.dp,
                    shape = RoundedCornerShape(16.dp),
                    clip = false,
                    ambientColor = Color(0x02000000),
                    spotColor = Color(0x04071D49)
                ),
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            border = BorderStroke(1.dp, BorderLight.copy(alpha = 0.7f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                items.forEachIndexed { index, item ->
                    val isSelected = selectedItem == index
                    
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { onItemSelected(index) }
                            .padding(vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        if (isSelected) DeepNavy else Color.Transparent
                                    )
                                    .padding(horizontal = 16.dp, vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = item.label,
                                    tint = if (isSelected) RoyalGold else TextSecondary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = item.label,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) DeepNavy else TextSecondary,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

data class NavigationItem(
    val label: String,
    val icon: ImageVector
)

// Premium Top Header
@Composable
fun PremiumTopHeader(
    storeName: String,
    userName: String,
    currentDate: String,
    alertCount: Int,
    onAlertsClick: () -> Unit,
    onSearchClick: () -> Unit,
    onSettingsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .shadow(
                elevation = 1.dp,
                shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
                clip = false,
                ambientColor = Color(0x02000000),
                spotColor = Color(0x03071D49)
            ),
        color = Color.White,
        shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp),
        border = BorderStroke(1.dp, BorderLight.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Showroom/Store Name, User info & Today's Date
            Column(
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Store,
                        contentDescription = null,
                        tint = RoyalGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = storeName,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = DeepNavy,
                            fontSize = 17.sp
                        )
                    )
                }
                
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "المسؤول: $userName",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextSecondary,
                            fontWeight = FontWeight.Medium
                        )
                    )
                    Text(
                        text = "•",
                        style = MaterialTheme.typography.bodySmall.copy(color = BorderLight)
                    )
                    Text(
                        text = currentDate,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextSecondary,
                            fontWeight = FontWeight.Normal
                        )
                    )
                }
            }
            
            // Minimalist Action Buttons (NO big background circles)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Search Action
                IconButton(
                    onClick = onSearchClick,
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "بحث",
                        tint = DeepNavy,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Alerts / Notifications Action
                Box(contentAlignment = Alignment.TopEnd) {
                    IconButton(
                        onClick = onAlertsClick,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "التنبيهات",
                            tint = DeepNavy,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    if (alertCount > 0) {
                        Box(
                            modifier = Modifier
                                .offset(x = 1.dp, y = (-1).dp)
                                .size(16.dp)
                                .background(DangerRed, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = alertCount.toString(),
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Settings Action
                IconButton(
                    onClick = onSettingsClick,
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "الإعدادات",
                        tint = DeepNavy,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}

