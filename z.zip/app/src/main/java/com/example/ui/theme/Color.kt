package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Colors - Premium Brand (Slate Blue / Dark Indigo)
val DeepNavy = Color(0xFF102A5C)
val RoyalGold = Color(0xFFD4AF37)

// UI Accent/Status Colors
val SuccessGreen = Color(0xFF22C55E)
val WarningAmber = Color(0xFFF59E0B)
val DangerRed = Color(0xFFEF4444)

// Surface and Background - Light soft grey backgrounds with pure white surfaces
val SoftBackground = Color(0xFFF7F8FA)
val SoftSurface = Color(0xFFFFFFFF)
val GrayLight = Color(0xFFEFF1F5)

// Typography & Borders
val TextDark = Color(0xFF0F172A)
val TextSecondary = Color(0xFF475569)
val BorderLight = Color(0xFFE2E8F0)
val DividerLight = Color(0xFFE2E8F0)

