package com.example.ui.screens

import android.app.DatePickerDialog
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Customer
import com.example.data.model.InstallmentBill
import com.example.data.model.Sale
import com.example.ui.components.Formatter
import com.example.ui.components.PremiumButton
import com.example.ui.components.PremiumCard
import com.example.ui.components.PremiumIconWrapper
import com.example.ui.components.PremiumTextField
import com.example.ui.theme.*
import com.example.ui.viewmodel.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

// ==========================================
// 1. SPLASH SCREEN
// ==========================================
@Composable
fun SplashScreen(onSplashFinished: () -> Unit) {
    var startAnimation by remember { mutableStateOf(false) }
    val alphaAnim by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0f,
        animationSpec = tween(durationMillis = 1500)
    )
    val scaleAnim by animateFloatAsState(
        targetValue = if (startAnimation) 1.05f else 0.8f,
        animationSpec = tween(durationMillis = 1500, easing = FastOutSlowInEasing)
    )

    LaunchedEffect(key1 = true) {
        startAnimation = true
        delay(2200)
        onSplashFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepNavy),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .scale(scaleAnim)
                .alpha(alphaAnim)
        ) {
            // Elegant golden brand logo drawn with icons and circles
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .background(color = RoyalGold.copy(alpha = 0.15f), shape = CircleShape)
                    .border(2.dp, RoyalGold, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AccountBalanceWallet,
                    contentDescription = null,
                    tint = RoyalGold,
                    modifier = Modifier.size(48.dp)
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "المبيعات والأقساط",
                style = MaterialTheme.typography.displayMedium.copy(
                    color = SoftSurface,
                    fontWeight = FontWeight.Bold
                ),
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "نظام إدارة المبيعات والأقساط الذكي",
                style = MaterialTheme.typography.bodyLarge.copy(
                    color = SoftBackground.copy(alpha = 0.7f)
                ),
                textAlign = TextAlign.Center
            )
        }
    }
}


// ==========================================
// 2. HOME SCREEN (الرئيسية)
// ==========================================
@Composable
fun MainDashboardStatCard(
    title: String,
    value: String,
    icon: ImageVector,
    iconColor: Color,
    iconBgColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .shadow(
                elevation = 2.dp,
                shape = RoundedCornerShape(20.dp),
                clip = false,
                ambientColor = Color(0x02000000),
                spotColor = Color(0x06071D49)
            ),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BorderLight.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = TextSecondary,
                        fontWeight = FontWeight.Bold
                    ),
                    maxLines = 1
                )
                PremiumIconWrapper(
                    icon = icon,
                    tint = iconColor,
                    backgroundColor = iconBgColor,
                    size = 36
                )
            }
            Text(
                text = value,
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = DeepNavy,
                    fontSize = 24.sp
                )
            )
        }
    }
}

@Composable
fun LargeShortcutCard(
    title: String,
    icon: ImageVector,
    iconColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(90.dp)
            .shadow(
                elevation = 2.dp,
                shape = RoundedCornerShape(20.dp),
                clip = false,
                ambientColor = Color(0x02000000),
                spotColor = Color(0x06071D49)
            )
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BorderLight.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            PremiumIconWrapper(
                icon = icon,
                tint = iconColor,
                backgroundColor = iconColor.copy(alpha = 0.1f),
                size = 48
            )
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = DeepNavy,
                    fontSize = 15.sp
                )
            )
        }
    }
}

@Composable
fun PremiumReportsDialog(
    reportsStats: ReportsStats,
    onDismiss: () -> Unit
) {
    val totalSales = reportsStats.totalSales
    val totalCapital = reportsStats.totalCapital
    val totalProfits = reportsStats.totalProfits
    val totalCollected = reportsStats.totalCollected
    val totalRemaining = reportsStats.totalRemaining
    
    val activeContractsCount = reportsStats.activeContractsCount
    val completedContractsCount = reportsStats.completedContractsCount

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = DeepNavy),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Text("إغلاق التقرير", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                PremiumIconWrapper(
                    icon = Icons.Default.TrendingUp,
                    tint = RoyalGold,
                    backgroundColor = RoyalGold.copy(alpha = 0.1f),
                    size = 40
                )
                Text(
                    text = "التقرير المالي المفصل",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = DeepNavy
                    )
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ReportMetricRow(
                        label = "إجمالي مبيعات العقود",
                        value = Formatter.formatCurrency(totalSales),
                        color = DeepNavy
                    )
                    ReportMetricRow(
                        label = "رأس المال الأصلي (نقداً)",
                        value = Formatter.formatCurrency(totalCapital),
                        color = TextSecondary
                    )
                    ReportMetricRow(
                        label = "الأرباح المتوقعة الإجمالية",
                        value = Formatter.formatCurrency(totalProfits),
                        color = RoyalGold
                    )
                    
                    Divider(color = BorderLight.copy(alpha = 0.5f))
                    
                    ReportMetricRow(
                        label = "إجمالي المبالغ المستلمة (المحصلة)",
                        value = Formatter.formatCurrency(totalCollected),
                        color = SuccessGreen
                    )
                    ReportMetricRow(
                        label = "إجمالي المستحقات المتبقية",
                        value = Formatter.formatCurrency(totalRemaining),
                        color = DangerRed
                    )
                }

                val collectionPercentage = if (totalSales > 0) (totalCollected / totalSales).toFloat() else 0f
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "نسبة التحصيل الفعلي",
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                        )
                        Text(
                            text = "${(collectionPercentage * 100).toInt()}%",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = SuccessGreen
                            )
                        )
                    }
                    LinearProgressIndicator(
                        progress = collectionPercentage,
                        color = SuccessGreen,
                        trackColor = BorderLight,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(GrayLight, RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("العقود النشطة", style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary))
                            Text(activeContractsCount.toString(), style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = DeepNavy))
                        }
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(GrayLight, RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("العقود المكتملة", style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary))
                            Text(completedContractsCount.toString(), style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = SuccessGreen))
                        }
                    }
                }
            }
        },
        shape = RoundedCornerShape(20.dp),
        containerColor = Color.White
    )
}

@Composable
fun ReportMetricRow(
    label: String,
    value: String,
    color: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary))
        Text(value, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = color))
    }
}

@Composable
fun PremiumPaymentsHistoryDialog(
    bills: List<InstallmentBill>,
    customers: List<Customer>,
    onDismiss: () -> Unit
) {
    val paidBills = remember(bills) {
        bills.filter { it.isPaid }.sortedByDescending { it.paymentDate ?: "" }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = DeepNavy),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Text("إغلاق", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                PremiumIconWrapper(
                    icon = Icons.Default.AddCard,
                    tint = RoyalGold,
                    backgroundColor = RoyalGold.copy(alpha = 0.1f),
                    size = 40
                )
                Text(
                    text = "سجل الدفعات والمقبوضات",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = DeepNavy
                    )
                )
            }
        },
        text = {
            Box(modifier = Modifier.fillMaxWidth().height(300.dp)) {
                if (paidBills.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("لا يوجد سجل دفعات حالياً", style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary))
                    }
                } else {
                    androidx.compose.foundation.lazy.LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(paidBills, key = { it.id }) { bill ->
                            val customer = customers.find { it.id == bill.customerId }
                            
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = GrayLight),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = customer?.name ?: "عميل مجهول",
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = DeepNavy
                                            )
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = bill.notes.ifEmpty { "دفعة سداد قسط" },
                                            style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary)
                                        )
                                        if (!bill.paymentDate.isNullOrEmpty()) {
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = bill.paymentDate,
                                                style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary, fontSize = 10.sp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = Formatter.formatCurrency(bill.amountPaid),
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = SuccessGreen
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        shape = RoundedCornerShape(20.dp),
        containerColor = Color.White
    )
}

@Composable
fun HomeScreen(viewModel: MainViewModel) {
    val stats by viewModel.dashboardStats.collectAsState()
    val customersCount by viewModel.totalCustomersCount.collectAsState()
    val recentBills by viewModel.bills.collectAsState()
    val allCustomers by viewModel.customers.collectAsState()
    val allSales by viewModel.sales.collectAsState()
    val reportsStats by viewModel.reportsStats.collectAsState()

    var showReportsDialog by remember { mutableStateOf(false) }
    var showPaymentsDialog by remember { mutableStateOf(false) }

    if (showReportsDialog) {
        PremiumReportsDialog(
            reportsStats = reportsStats,
            onDismiss = { showReportsDialog = false }
        )
    }

    if (showPaymentsDialog) {
        PremiumPaymentsHistoryDialog(
            bills = recentBills,
            customers = allCustomers,
            onDismiss = { showPaymentsDialog = false }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Stats Overview Section (Four Small Cards in a compact Grid at the very top)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Row 1: عدد العملاء & إجمالي العقود
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MainDashboardStatCard(
                        title = "عدد العملاء",
                        value = customersCount.toString(),
                        icon = Icons.Default.People,
                        iconColor = DeepNavy,
                        iconBgColor = DeepNavy.copy(alpha = 0.08f),
                        modifier = Modifier.weight(1f)
                    )
                    MainDashboardStatCard(
                        title = "إجمالي العقود",
                        value = Formatter.formatCurrency(stats.totalSales),
                        icon = Icons.Default.Assignment,
                        iconColor = RoyalGold,
                        iconBgColor = RoyalGold.copy(alpha = 0.1f),
                        modifier = Modifier.weight(1f)
                    )
                }

                // Row 2: إجمالي المتبقي & العملاء المتأخرون
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MainDashboardStatCard(
                        title = "إجمالي المتبقي",
                        value = Formatter.formatCurrency(stats.totalRemaining),
                        icon = Icons.Default.AccountBalanceWallet,
                        iconColor = SuccessGreen,
                        iconBgColor = SuccessGreen.copy(alpha = 0.08f),
                        modifier = Modifier.weight(1f)
                    )
                    MainDashboardStatCard(
                        title = "العملاء المتأخرون",
                        value = stats.overdueCount.toString(),
                        icon = Icons.Default.ErrorOutline,
                        iconColor = DangerRed,
                        iconBgColor = DangerRed.copy(alpha = 0.08f),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Upcoming Installments Card (بطاقة الاستحقاقات القادمة)
        item {
            UpcomingInstallmentsCard(
                count = stats.upcomingCount,
                onClick = { viewModel.currentScreen = AppScreen.ALERTS }
            )
        }

        // Quick Shortcuts (الوصول السريع) - 4 essential items in a clean grid
        item {
            QuickAccessGrid(
                onAddCustomerClick = { viewModel.currentScreen = AppScreen.ADD_INSTALLMENT },
                onCustomersClick = { viewModel.currentScreen = AppScreen.CUSTOMERS },
                onAlertsClick = { viewModel.currentScreen = AppScreen.ALERTS },
                onReportsClick = { showReportsDialog = true }
            )
        }



        // Sales Analytics Brief (إحصائيات مختصرة)
        item {
            PremiumCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "إحصائيات مختصرة للأرباح",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold, 
                            color = DeepNavy,
                            fontSize = 15.sp
                        )
                    )
                    Text(
                        text = "نشاط دوري",
                        style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                PremiumAnalyticsGraph(stats.totalSales)
            }
        }
    }
}

@Composable
fun UpcomingInstallmentsCard(
    count: Int,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 1.dp,
                shape = RoundedCornerShape(16.dp),
                clip = false,
                ambientColor = Color(0x02000000),
                spotColor = Color(0x03071D49)
            )
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BorderLight.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(WarningAmber.copy(alpha = 0.08f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = null,
                        tint = WarningAmber,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column {
                    Text(
                        text = "الاستحقاقات القادمة قريباً",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = DeepNavy,
                            fontSize = 15.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "الأقساط المستحقة خلال الفترة القادمة",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                    )
                }
            }
            
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .background(WarningAmber, RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "$count قسط",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = null,
                    tint = TextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun QuickAccessGrid(
    onAddCustomerClick: () -> Unit,
    onCustomersClick: () -> Unit,
    onAlertsClick: () -> Unit,
    onReportsClick: () -> Unit
) {
    val items = listOf(
        QuickAccessData("إضافة عميل", Icons.Default.PersonAdd, DeepNavy, onAddCustomerClick),
        QuickAccessData("العملاء", Icons.Default.People, RoyalGold, onCustomersClick),
        QuickAccessData("الاستحقاقات", Icons.Default.Notifications, WarningAmber, onAlertsClick),
        QuickAccessData("التقارير", Icons.Default.Assessment, SuccessGreen, onReportsClick)
    )

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "الوصول السريع",
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = DeepNavy,
                fontSize = 18.sp
            )
        )
        
        // Grid of 2-columns
        val chunked = items.chunked(2)
        chunked.forEach { rowItems ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                rowItems.forEach { item ->
                    Box(
                        modifier = Modifier.weight(1f)
                    ) {
                        QuickAccessCard(item)
                    }
                }
                // Fill remaining spaces in row to keep layout balanced
                if (rowItems.size < 2) {
                    repeat(2 - rowItems.size) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

data class QuickAccessData(
    val title: String,
    val icon: ImageVector,
    val color: Color,
    val onClick: () -> Unit
)

@Composable
fun QuickAccessCard(data: QuickAccessData) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(85.dp)
            .shadow(
                elevation = 1.dp,
                shape = RoundedCornerShape(16.dp),
                clip = false,
                ambientColor = Color(0x01000000),
                spotColor = Color(0x03071D49)
            )
            .clickable(onClick = data.onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BorderLight.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(data.color.copy(alpha = 0.08f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = data.icon,
                    contentDescription = null,
                    tint = data.color,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = data.title,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = DeepNavy,
                    fontSize = 12.sp
                ),
                maxLines = 1,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun MiniStatCard(
    title: String,
    count: String,
    accentColor: Color
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderLight, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = SoftSurface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary),
                maxLines = 1,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = count,
                style = MaterialTheme.typography.displayLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = accentColor
                )
            )
        }
    }
}

@Composable
fun ShortcutButton(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    badgeCount: Int = 0
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(8.dp)
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .background(color = DeepNavy, shape = CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = RoyalGold,
                    modifier = Modifier.size(26.dp)
                )
            }
            if (badgeCount > 0) {
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .background(color = DangerRed, shape = CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = badgeCount.toString(),
                        color = SoftSurface,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge.copy(
                color = TextDark,
                fontWeight = FontWeight.Medium
            )
        )
    }
}

@Composable
fun RecentTransactionRow(
    customerName: String,
    dueDate: String,
    amount: Double,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(color = SoftSurface, shape = RoundedCornerShape(16.dp))
            .border(1.dp, BorderLight, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            PremiumIconWrapper(
                icon = Icons.Default.Person,
                tint = TextDark,
                backgroundColor = SoftBackground,
                size = 40
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = customerName,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TextDark)
                )
                Text(
                    text = "تاريخ الاستحقاق: $dueDate",
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                )
            }
        }
        Text(
            text = Formatter.formatCurrency(amount),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepNavy)
        )
    }
}

// Gorgeous Custom Draw Graph
@Composable
fun PremiumAnalyticsGraph(totalSales: Double) {
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
    ) {
        // Hardcoded elegant curves to simulate periodic financial cycles
        val points = listOf(
            Offset(0f, 140f),
            Offset(0.15f, 90f),
            Offset(0.3f, 130f),
            Offset(0.45f, 60f),
            Offset(0.6f, 110f),
            Offset(0.75f, 40f),
            Offset(0.9f, 80f),
            Offset(1f, 30f)
        )

        val width = size.width
        val height = size.height

        // Draw background grid lines
        val gridLines = 4
        for (i in 0..gridLines) {
            val y = (height / gridLines) * i
            drawLine(
                color = BorderLight.copy(alpha = 0.5f),
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 1.dp.toPx()
            )
        }

        // Draw graph gradient path
        val path = Path().apply {
            moveTo(0f, height)
            for (i in points.indices) {
                val p = points[i]
                lineTo(p.x * width, p.y * height / 180f * 150f)
            }
            lineTo(width, height)
            close()
        }

        drawPath(
            path = path,
            brush = Brush.verticalGradient(
                colors = listOf(
                    RoyalGold.copy(alpha = 0.25f),
                    RoyalGold.copy(alpha = 0.0f)
                )
            )
        )

        // Draw graph stroke line
        val linePath = Path().apply {
            val first = points.first()
            moveTo(first.x * width, first.y * height / 180f * 150f)
            for (i in 1 until points.size) {
                val p = points[i]
                lineTo(p.x * width, p.y * height / 180f * 150f)
            }
        }

        drawPath(
            path = linePath,
            color = RoyalGold,
            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
        )

        // Draw circular nodes
        for (p in points) {
            val center = Offset(p.x * width, p.y * height / 180f * 150f)
            drawCircle(
                color = DeepNavy,
                radius = 5.dp.toPx(),
                center = center
            )
            drawCircle(
                color = RoyalGold,
                radius = 3.dp.toPx(),
                center = center
            )
        }
    }
    Spacer(modifier = Modifier.height(10.dp))
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text("١ يوليو", style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary))
        Text("١٠ يوليو", style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary))
        Text("٢٠ يوليو", style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary))
        Text("٣٠ يوليو", style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary))
    }
}


// ==========================================
// 3. ADD INSTALLMENT SCREEN (إضافة قسط)
// ==========================================
@Composable
fun AddInstallmentScreen(viewModel: MainViewModel) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Large Premium Header with Back Arrow
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.currentScreen = AppScreen.HOME },
                modifier = Modifier
                    .background(SoftSurface, CircleShape)
                    .border(1.dp, BorderLight, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = DeepNavy
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(
                    text = "إضافة قسط جديد",
                    style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold, color = TextDark)
                )
                Text(
                    text = "الخطوة ${viewModel.currentStep} من 4",
                    style = MaterialTheme.typography.bodyMedium.copy(color = RoyalGold, fontWeight = FontWeight.Bold)
                )
            }
        }

        // Horizontal Stepper Progress Indicator
        HorizontalStepperProgress(currentStep = viewModel.currentStep)

        // Conditional rendering for steps
        when (viewModel.currentStep) {
            1 -> StepOneCustomerDetails(viewModel)
            2 -> StepTwoItemDetails(viewModel)
            3 -> StepThreeCalculations(viewModel)
            4 -> StepFourReview(viewModel)
        }

        // Dynamic navigation buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (viewModel.currentStep > 1) {
                Box(modifier = Modifier.weight(1f)) {
                    PremiumButton(
                        text = "رجوع",
                        onClick = { viewModel.currentStep-- },
                        isSecondary = true
                    )
                }
            }
            
            Box(modifier = Modifier.weight(1f)) {
                if (viewModel.currentStep < 4) {
                    PremiumButton(
                        text = "التالي",
                        onClick = {
                            if (validateStep(viewModel.currentStep, viewModel, context)) {
                                viewModel.currentStep++
                            }
                        }
                    )
                } else {
                    PremiumButton(
                        text = "تأكيد حفظ القسط",
                        onClick = {
                            viewModel.saveNewInstallment(
                                context = context,
                                onError = { errMsg ->
                                    Toast.makeText(context, errMsg, Toast.LENGTH_LONG).show()
                                },
                                onComplete = {
                                    Toast.makeText(context, "تم حفظ القسط بنجاح!", Toast.LENGTH_LONG).show()
                                    viewModel.currentScreen = AppScreen.HOME
                                }
                            )
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                viewModel.resetStepper()
                Toast.makeText(context, "تم إلغاء العملية وتصفير كافة الحقول", Toast.LENGTH_SHORT).show()
                viewModel.currentScreen = AppScreen.HOME
            },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Delete,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.padding(end = 8.dp)
            )
            Text(
                text = "إلغاء العملية وحذف بيانات العميل الحالية",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodyMedium
            )
        }
        
        Spacer(modifier = Modifier.height(100.dp))
    }
}

fun validateStep(step: Int, vm: MainViewModel, context: android.content.Context): Boolean {
    when (step) {
        1 -> {
            if (vm.stepCustomerName.trim().isEmpty()) {
                Toast.makeText(context, "يرجى إدخال اسم العميل", Toast.LENGTH_SHORT).show()
                return false
            }
            val customerPhone = vm.stepCustomerPhone.trim()
            if (customerPhone.isEmpty()) {
                Toast.makeText(context, "يرجى إدخال رقم الهاتف", Toast.LENGTH_SHORT).show()
                return false
            }
            if (customerPhone.length != 11) {
                Toast.makeText(context, "يجب أن يتكون رقم هاتف العميل من 11 رقماً حصراً", Toast.LENGTH_LONG).show()
                return false
            }
            val customerNatId = vm.stepCustomerNationalId.trim()
            if (customerNatId.isNotEmpty() && customerNatId.length != 12) {
                Toast.makeText(context, "يجب أن يتكون رقم البطاقة الوطنية للعميل من 12 رقماً حصراً", Toast.LENGTH_LONG).show()
                return false
            }
            if (vm.stepCustomerHasGuarantor) {
                if (vm.stepGuarantorName.trim().isEmpty()) {
                    Toast.makeText(context, "يرجى إدخال اسم الكفيل", Toast.LENGTH_SHORT).show()
                    return false
                }
                val guarantorPhone = vm.stepGuarantorPhone.trim()
                if (guarantorPhone.isEmpty()) {
                    Toast.makeText(context, "يرجى إدخال هاتف الكفيل", Toast.LENGTH_SHORT).show()
                    return false
                }
                if (guarantorPhone.length != 11) {
                    Toast.makeText(context, "يجب أن يتكون رقم هاتف الكفيل من 11 رقماً حصراً", Toast.LENGTH_LONG).show()
                    return false
                }
                val guarantorNatId = vm.stepGuarantorNationalId.trim()
                if (guarantorNatId.isNotEmpty() && guarantorNatId.length != 12) {
                    Toast.makeText(context, "يجب أن يتكون رقم البطاقة الوطنية للكفيل من 12 رقماً حصراً", Toast.LENGTH_LONG).show()
                    return false
                }
            }
        }
        2 -> {
            if (vm.stepItemName.trim().isEmpty()) {
                Toast.makeText(context, "يرجى إدخال اسم السلعة المباعة", Toast.LENGTH_SHORT).show()
                return false
            }
        }
        3 -> {
            val inst = Formatter.sanitizeAmount(vm.stepInstallmentPrice)
            val down = Formatter.sanitizeAmount(vm.stepDownPayment)
            val expectedInst = Formatter.sanitizeAmount(vm.stepExpectedInstallment)

            if (inst <= 0) {
                Toast.makeText(context, "يرجى التحقق من سعر التقسيط", Toast.LENGTH_SHORT).show()
                return false
            }
            if (down < 0.0) {
                Toast.makeText(context, "الدفعة الأولى غير صالحة، يرجى إدخال قيمة صحيحة", Toast.LENGTH_SHORT).show()
                return false
            }
            if (down > inst) {
                Toast.makeText(context, "قيمة الدفعة الأولى لا يمكن أن تكون أكبر من سعر التقسيط", Toast.LENGTH_SHORT).show()
                return false
            }
            if (expectedInst <= 0.0) {
                Toast.makeText(context, "يرجى إدخال قيمة القسط الشهري المتوقع", Toast.LENGTH_SHORT).show()
                return false
            }
        }
    }
    return true
}

@Composable
fun HorizontalStepperProgress(currentStep: Int) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 1..4) {
            val isActive = i <= currentStep
            val isCurrent = i == currentStep
            
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(if (i < 4) 1f else 0.0001f, fill = i < 4)
            ) {
                // Circle Step Number
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(
                            color = when {
                                isCurrent -> RoyalGold
                                isActive -> DeepNavy
                                else -> BorderLight
                            },
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = i.toString(),
                        color = if (isActive) SoftSurface else TextSecondary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                // Connecting Line
                if (i < 4) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(4.dp)
                            .padding(horizontal = 4.dp)
                            .background(
                                color = if (i < currentStep) DeepNavy else BorderLight,
                                shape = RoundedCornerShape(2.dp)
                            )
                    )
                }
            }
        }
    }
}

// Stage 1: Customer details
@Composable
fun StepOneCustomerDetails(vm: MainViewModel) {
    val context = LocalContext.current
    val provinces = listOf("بغداد", "البصرة", "نينوى", "الأنبار", "بابل", "كربلاء", "النجف", "صلاح الدين", "ديالى", "ميسان", "ذي قار", "المثنى", "القادسية", "واسط", "كركوك", "أربيل", "السليمانية", "دهوك")
    var isProvinceExpanded by remember { mutableStateOf(false) }

    PremiumCard {
        Text(
            text = "بيانات العميل الأساسية",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepNavy),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Guarantor toggles
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(modifier = Modifier.weight(1f)) {
                SelectableToggleCard(
                    title = "بدون كفيل",
                    isSelected = !vm.stepCustomerHasGuarantor,
                    onClick = { vm.stepCustomerHasGuarantor = false }
                )
            }
            Box(modifier = Modifier.weight(1f)) {
                SelectableToggleCard(
                    title = "مع كفيل",
                    isSelected = vm.stepCustomerHasGuarantor,
                    onClick = { vm.stepCustomerHasGuarantor = true }
                )
            }
        }

        PremiumTextField(
            value = vm.stepCustomerName,
            onValueChange = { vm.stepCustomerName = it },
            label = "الاسم الكامل *",
            placeholder = "",
            leadingIcon = Icons.Default.Person,
            isSuccess = vm.stepCustomerName.trim().length > 3
        )
        Spacer(modifier = Modifier.height(12.dp))

        PremiumTextField(
            value = vm.stepCustomerPhone,
            onValueChange = { input ->
                val clean = Formatter.convertArabicToEnglishDigits(input).filter { it.isDigit() }
                if (clean.length <= 11) {
                    vm.stepCustomerPhone = clean
                }
            },
            label = "رقم الهاتف *",
            placeholder = "",
            leadingIcon = Icons.Default.Phone,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            isSuccess = vm.stepCustomerPhone.trim().length == 11
        )
        Spacer(modifier = Modifier.height(12.dp))

        PremiumTextField(
            value = vm.stepCustomerJob,
            onValueChange = { vm.stepCustomerJob = it },
            label = "المهنة",
            placeholder = "",
            leadingIcon = Icons.Default.Work
        )
        Spacer(modifier = Modifier.height(12.dp))

        PremiumTextField(
            value = vm.stepCustomerNationalId,
            onValueChange = { input ->
                val clean = Formatter.convertArabicToEnglishDigits(input).filter { it.isDigit() }
                if (clean.length <= 12) {
                    vm.stepCustomerNationalId = clean
                }
            },
            label = "رقم البطاقة الوطنية",
            placeholder = "",
            leadingIcon = Icons.Default.Badge,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            isSuccess = vm.stepCustomerNationalId.trim().length == 12
        )
        Spacer(modifier = Modifier.height(12.dp))

        // Province Dropdown Trigger
        Box(modifier = Modifier.fillModifierDrop()) {
            PremiumTextField(
                value = vm.stepCustomerProvince,
                onValueChange = {},
                label = "المحافظة",
                placeholder = "",
                readOnly = true,
                leadingIcon = Icons.Default.LocationCity,
                trailingIcon = {
                    IconButton(onClick = { isProvinceExpanded = true }) {
                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null)
                    }
                },
                modifier = Modifier.clickable { isProvinceExpanded = true }
            )
            DropdownMenu(
                expanded = isProvinceExpanded,
                onDismissRequest = { isProvinceExpanded = false },
                modifier = Modifier.background(SoftSurface)
            ) {
                provinces.forEach { p ->
                    DropdownMenuItem(
                        text = { Text(p, style = MaterialTheme.typography.bodyLarge) },
                        onClick = {
                            vm.stepCustomerProvince = p
                            isProvinceExpanded = false
                        }
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(12.dp))

        PremiumTextField(
            value = vm.stepCustomerLandmark,
            onValueChange = { vm.stepCustomerLandmark = it },
            label = "أقرب نقطة دالة",
            placeholder = "",
            leadingIcon = Icons.Default.Explore
        )
        Spacer(modifier = Modifier.height(12.dp))

        // Date picker for registration
        PremiumTextField(
            value = vm.stepCustomerRegDate,
            onValueChange = {},
            label = "تاريخ التسجيل",
            placeholder = "",
            readOnly = true,
            leadingIcon = Icons.Default.DateRange,
            trailingIcon = {
                IconButton(onClick = {
                    showDatePicker(context, vm.stepCustomerRegDate) { vm.stepCustomerRegDate = it }
                }) {
                    Icon(imageVector = Icons.Default.CalendarToday, contentDescription = null, tint = RoyalGold)
                }
            }
        )
    }

    // Guarantor fields if selected
    if (vm.stepCustomerHasGuarantor) {
        Spacer(modifier = Modifier.height(16.dp))
        PremiumCard {
            Text(
                text = "بيانات الكفيل الضامن",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepNavy),
                modifier = Modifier.padding(bottom = 16.dp)
            )

            PremiumTextField(
                value = vm.stepGuarantorName,
                onValueChange = { vm.stepGuarantorName = it },
                label = "اسم الكفيل الكامل *",
                placeholder = "",
                leadingIcon = Icons.Default.Person,
                isSuccess = vm.stepGuarantorName.trim().length > 3
            )
            Spacer(modifier = Modifier.height(12.dp))

            PremiumTextField(
                value = vm.stepGuarantorPhone,
                onValueChange = { input ->
                    val clean = Formatter.convertArabicToEnglishDigits(input).filter { it.isDigit() }
                    if (clean.length <= 11) {
                        vm.stepGuarantorPhone = clean
                    }
                },
                label = "هاتف الكفيل *",
                placeholder = "",
                leadingIcon = Icons.Default.Phone,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                isSuccess = vm.stepGuarantorPhone.trim().length == 11
            )
            Spacer(modifier = Modifier.height(12.dp))

            PremiumTextField(
                value = vm.stepGuarantorJob,
                onValueChange = { vm.stepGuarantorJob = it },
                label = "مهنة الكفيل",
                placeholder = "",
                leadingIcon = Icons.Default.Work
            )
            Spacer(modifier = Modifier.height(12.dp))

            PremiumTextField(
                value = vm.stepGuarantorNationalId,
                onValueChange = { input ->
                    val clean = Formatter.convertArabicToEnglishDigits(input).filter { it.isDigit() }
                    if (clean.length <= 12) {
                        vm.stepGuarantorNationalId = clean
                    }
                },
                label = "رقم البطاقة الوطنية للكفيل",
                placeholder = "",
                leadingIcon = Icons.Default.Badge,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                isSuccess = vm.stepGuarantorNationalId.trim().length == 12
            )
        }
    }
}

fun Modifier.fillModifierDrop(): Modifier = this.fillMaxWidth()

@Composable
fun SelectableToggleCard(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(58.dp)
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) RoyalGold else BorderLight,
                shape = RoundedCornerShape(18.dp)
            )
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) DeepNavy else SoftSurface
        )
    ) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) SoftSurface else TextDark
                )
            )
        }
    }
}

// Stage 2: Item details
@Composable
fun StepTwoItemDetails(vm: MainViewModel) {
    PremiumCard {
        Text(
            text = "بيانات السلعة المباعة",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepNavy),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        PremiumTextField(
            value = vm.stepItemName,
            onValueChange = { vm.stepItemName = it },
            label = "اسم السلعة / الخدمة *",
            placeholder = "مثلاً: آيفون 15 برو، تبريد حائطي...",
            leadingIcon = Icons.Default.Inventory2,
            isSuccess = vm.stepItemName.trim().isNotEmpty()
        )
        Spacer(modifier = Modifier.height(16.dp))

        PremiumTextField(
            value = vm.stepItemDescription,
            onValueChange = { vm.stepItemDescription = it },
            label = "الوصف والمواصفات",
            placeholder = "اكتب تفاصيل إضافية عن السلعة (سيريال نمبر، اللون، الحالة...)",
            leadingIcon = Icons.Default.Description
        )
    }
}

// Stage 3: Calculations
@Composable
fun StepThreeCalculations(vm: MainViewModel) {
    val context = LocalContext.current

    PremiumCard {
        Text(
            text = "الحسابات المالية للعقد",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepNavy),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        PremiumTextField(
            value = vm.stepInstallmentPrice,
            onValueChange = { vm.stepInstallmentPrice = Formatter.updatePriceField(vm.stepInstallmentPrice, it) },
            label = "إجمالي سعر البيع بالتقسيط *",
            placeholder = "أدخل إجمالي سعر التقسيط",
            leadingIcon = Icons.Default.PriceCheck,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            isSuccess = Formatter.sanitizeAmount(vm.stepInstallmentPrice) > 0,
            trailingIcon = { Text("د.ع", modifier = Modifier.padding(end = 12.dp), color = RoyalGold, fontWeight = FontWeight.Bold) }
        )
        if (vm.stepInstallmentPrice.isNotEmpty()) {
            Text(
                text = "المبلغ: " + Formatter.formatCurrency(Formatter.sanitizeAmount(vm.stepInstallmentPrice)),
                style = MaterialTheme.typography.bodySmall.copy(color = SuccessGreen, fontWeight = FontWeight.Medium),
                modifier = Modifier.padding(start = 8.dp, top = 2.dp, bottom = 4.dp)
            )
        }
        Spacer(modifier = Modifier.height(12.dp))

        PremiumTextField(
            value = vm.stepDownPayment,
            onValueChange = { vm.stepDownPayment = Formatter.updatePriceField(vm.stepDownPayment, it) },
            label = "الدفعة الأولى المقدمة *",
            placeholder = "أدخل مبلغ الدفعة الأولى المقدمة",
            leadingIcon = Icons.Default.MonetizationOn,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            isSuccess = Formatter.sanitizeAmount(vm.stepDownPayment) >= 0.0,
            trailingIcon = { Text("د.ع", modifier = Modifier.padding(end = 12.dp), color = RoyalGold, fontWeight = FontWeight.Bold) }
        )
        if (vm.stepDownPayment.isNotEmpty()) {
            Text(
                text = "المبلغ: " + Formatter.formatCurrency(Formatter.sanitizeAmount(vm.stepDownPayment)),
                style = MaterialTheme.typography.bodySmall.copy(color = SuccessGreen, fontWeight = FontWeight.Medium),
                modifier = Modifier.padding(start = 8.dp, top = 2.dp, bottom = 4.dp)
            )
        }
        Spacer(modifier = Modifier.height(12.dp))

        PremiumTextField(
            value = vm.stepExpectedInstallment,
            onValueChange = { vm.stepExpectedInstallment = Formatter.updatePriceField(vm.stepExpectedInstallment, it) },
            label = "قيمة القسط الشهري المتوقع *",
            placeholder = "أدخل قيمة القسط الشهري المتوقع",
            leadingIcon = Icons.Default.FormatListNumbered,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            isSuccess = Formatter.sanitizeAmount(vm.stepExpectedInstallment) > 0,
            trailingIcon = { Text("د.ع", modifier = Modifier.padding(end = 12.dp), color = RoyalGold, fontWeight = FontWeight.Bold) }
        )
        if (vm.stepExpectedInstallment.isNotEmpty()) {
            Text(
                text = "المبلغ: " + Formatter.formatCurrency(Formatter.sanitizeAmount(vm.stepExpectedInstallment)),
                style = MaterialTheme.typography.bodySmall.copy(color = SuccessGreen, fontWeight = FontWeight.Medium),
                modifier = Modifier.padding(start = 8.dp, top = 2.dp, bottom = 4.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Live Summary Card (Clean White Card instead of DeepNavy)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderLight, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "ملخص الحساب المالي",
                    style = MaterialTheme.typography.titleMedium.copy(color = DeepNavy, fontWeight = FontWeight.Bold)
                )
                Divider(color = BorderLight)
                SummaryItemRow(label = "إجمالي سعر البيع بالتقسيط:", value = Formatter.formatCurrency(Formatter.sanitizeAmount(vm.stepInstallmentPrice)), color = TextDark)
                SummaryItemRow(label = "الدفعة الأولى المقدمة:", value = Formatter.formatCurrency(Formatter.sanitizeAmount(vm.stepDownPayment)), color = TextDark)
                SummaryItemRow(label = "صافي المبلغ المتبقي في الذمة:", value = Formatter.formatCurrency(vm.stepRemainingAmount), color = DangerRed, isBold = true)
                SummaryItemRow(label = "قيمة القسط الشهري المتوقع:", value = Formatter.formatCurrency(Formatter.sanitizeAmount(vm.stepExpectedInstallment)), color = SuccessGreen, isBold = true)
            }
        }
    }
}

@Composable
fun SummaryItemRow(label: String, value: String, color: Color, isBold: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyLarge.copy(
                color = color,
                fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium
            )
        )
    }
}

// Stage 4: Review and confirmation
@Composable
fun StepFourReview(vm: MainViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        // Customer details Review
        ReviewSectionCard(
            title = "بيانات العميل",
            onEdit = { vm.currentStep = 1 }
        ) {
            ReviewRow(label = "الاسم الكامل:", value = vm.stepCustomerName)
            ReviewRow(label = "رقم الهاتف:", value = vm.stepCustomerPhone)
            ReviewRow(label = "المهنة:", value = vm.stepCustomerJob.ifEmpty { "غير محدد" })
            ReviewRow(label = "المحافظة:", value = vm.stepCustomerProvince)
            ReviewRow(label = "الضامن:", value = if (vm.stepCustomerHasGuarantor) "مع كفيل (الاسم: ${vm.stepGuarantorName})" else "بدون كفيل")
        }

        // Product details Review
        ReviewSectionCard(
            title = "بيانات السلعة",
            onEdit = { vm.currentStep = 2 }
        ) {
            ReviewRow(label = "اسم السلعة:", value = vm.stepItemName)
            ReviewRow(label = "المواصفات:", value = vm.stepItemDescription.ifEmpty { "لا يوجد" })
        }

        // Calculations details Review
        ReviewSectionCard(
            title = "ملخص العقد المالي",
            onEdit = { vm.currentStep = 3 }
        ) {
            ReviewRow(label = "إجمالي سعر البيع بالتقسيط:", value = Formatter.formatCurrency(Formatter.sanitizeAmount(vm.stepInstallmentPrice)))
            ReviewRow(label = "الدفعة الأولى المقدمة:", value = Formatter.formatCurrency(Formatter.sanitizeAmount(vm.stepDownPayment)))
            ReviewRow(label = "صافي المبلغ المتبقي في الذمة:", value = Formatter.formatCurrency(vm.stepRemainingAmount), color = DangerRed, isBold = true)
            ReviewRow(label = "قيمة القسط الشهري المتوقع:", value = Formatter.formatCurrency(Formatter.sanitizeAmount(vm.stepExpectedInstallment)), color = SuccessGreen, isBold = true)
        }
    }
}

@Composable
fun ReviewSectionCard(
    title: String,
    onEdit: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    PremiumCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepNavy)
            )
            TextButton(onClick = onEdit) {
                Icon(imageVector = Icons.Default.Edit, contentDescription = "تعديل", tint = RoyalGold, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("تعديل", style = MaterialTheme.typography.bodyMedium.copy(color = RoyalGold, fontWeight = FontWeight.Bold))
            }
        }
        Divider(color = BorderLight, modifier = Modifier.padding(vertical = 8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            content()
        }
    }
}

@Composable
fun ReviewRow(label: String, value: String, color: Color = TextDark, isBold: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(
                color = color,
                fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium
            )
        )
    }
}


// ==========================================
// 4. CUSTOMERS SCREEN (العملاء)
// ==========================================
@Composable
fun CustomersScreen(viewModel: MainViewModel) {
    val searchQuery by viewModel.customerSearchQuery.collectAsState()
    val statusFilter by viewModel.customerStatusFilter.collectAsState()
    val customerUiStates by viewModel.filteredCustomerUiStates.collectAsState()

    var customerToDelete by remember { mutableStateOf<Customer?>(null) }
    
    // Progressive Smart Loading / Pagination (Lazy Loading)
    val listState = rememberLazyListState()
    var visibleLimit by remember { mutableStateOf(20) }

    // Reset pagination window back to initial 20 on search/filter changes to ensure consistency
    LaunchedEffect(searchQuery, statusFilter) {
        visibleLimit = 20
    }

    // Scroll trigger condition to dynamically stream additional pages of 20 customers
    val shouldLoadMore = remember {
        derivedStateOf {
            val lastVisibleItem = listState.layoutInfo.visibleItemsInfo.lastOrNull() ?: return@derivedStateOf false
            lastVisibleItem.index >= visibleLimit - 5
        }
    }

    LaunchedEffect(shouldLoadMore.value) {
        if (shouldLoadMore.value) {
            visibleLimit = (visibleLimit + 20).coerceAtMost(customerUiStates.size)
        }
    }

    val paginatedCustomers = remember(customerUiStates, visibleLimit) {
        customerUiStates.take(visibleLimit)
    }

    LazyColumn(
        state = listState,
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "قائمة العملاء",
                style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold, color = TextDark)
            )
        }

        // Live Search Input with Cairo theme
        item {
            PremiumTextField(
                value = searchQuery,
                onValueChange = { viewModel.customerSearchQuery.value = it },
                label = "البحث السريع عن عميل",
                placeholder = "ابحث بالاسم أو رقم الهاتف...",
                leadingIcon = Icons.Default.Search,
                isSuccess = searchQuery.length >= 3
            )
        }

        // Elegant Filter Pills Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterPill(title = "الكل", isSelected = statusFilter == "ALL", onClick = { viewModel.customerStatusFilter.value = "ALL" })
                FilterPill(title = "المتأخرين", isSelected = statusFilter == "OVERDUE", onClick = { viewModel.customerStatusFilter.value = "OVERDUE" })
                FilterPill(title = "النشطين", isSelected = statusFilter == "ACTIVE", onClick = { viewModel.customerStatusFilter.value = "ACTIVE" })
            }
        }

        if (customerUiStates.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 64.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        PremiumIconWrapper(
                            icon = Icons.Default.GroupOff,
                            tint = TextSecondary,
                            backgroundColor = BorderLight,
                            size = 80
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "لم يتم العثور على أي عملاء",
                            style = MaterialTheme.typography.titleMedium.copy(color = TextSecondary)
                        )
                    }
                }
            }
        } else {
            itemsIndexed(paginatedCustomers, key = { _, state -> state.customer.id }) { index, state ->
                val rowBgColor = if (index % 2 == 0) SoftSurface else GrayLight.copy(alpha = 0.5f)

                CustomerCardRow(
                    state = state,
                    backgroundColor = rowBgColor,
                    onClick = {
                        viewModel.selectedCustomerId.value = state.customer.id
                        viewModel.currentScreen = AppScreen.CUSTOMER_DETAILS
                    },
                    onDeleteClick = {
                        customerToDelete = state.customer
                    }
                )
            }
        }
    }

    customerToDelete?.let { customer ->
        AlertDialog(
            onDismissRequest = { customerToDelete = null },
            title = {
                Text(
                    text = "تأكيد حذف العميل",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.titleMedium
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من حذف العميل (${customer.name}) وجميع بيانات أقساطه نهائياً؟ هذا الإجراء لا يمكن التراجع عنه.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextDark
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteCustomerFully(customer) {
                            customerToDelete = null
                        }
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("نعم، تأكيد الحذف", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { customerToDelete = null }
                ) {
                    Text("إلغاء", fontWeight = FontWeight.Bold, color = TextSecondary)
                }
            }
        )
    }
}

@Composable
fun FilterPill(title: String, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) DeepNavy else SoftSurface)
            .border(1.dp, if (isSelected) DeepNavy else BorderLight, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = if (isSelected) SoftSurface else TextDark
            )
        )
    }
}

@Composable
fun CustomerCardRow(
    state: CustomerUiState,
    backgroundColor: Color = SoftSurface,
    onClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val customer = state.customer
    val overdueCount = state.overdueCount
    val isCompleted = state.isCompleted
    val totalRemaining = state.totalRemaining
    val nextInstallmentStr = state.nextInstallmentStr

    val context = LocalContext.current
    val initial = if (customer.name.isNotEmpty()) customer.name.first().toString() else "ع"

    PremiumCard(
        backgroundColor = SoftSurface,
        modifier = Modifier.padding(bottom = 6.dp)
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Top Row: Avatar, Name & Phone, Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Alphabetic Avatar with Slate Navy background
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .background(color = DeepNavy, shape = CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = initial,
                            color = RoyalGold,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = customer.name,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextDark,
                                fontSize = 15.sp
                            ),
                            maxLines = 1
                        )
                        Text(
                            text = customer.phone,
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary),
                            maxLines = 1
                        )
                    }
                }

                // Status Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            color = when {
                                isCompleted -> SuccessGreen.copy(alpha = 0.08f)
                                overdueCount > 0 -> DangerRed.copy(alpha = 0.08f)
                                else -> WarningAmber.copy(alpha = 0.08f)
                            }
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = when {
                            isCompleted -> "مكتمل"
                            overdueCount > 0 -> "متأخر ($overdueCount)"
                            else -> "منتظم"
                        },
                        color = when {
                            isCompleted -> SuccessGreen
                            overdueCount > 0 -> DangerRed
                            else -> WarningAmber
                        },
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }

            Divider(color = BorderLight.copy(alpha = 0.3f), thickness = 0.8.dp)

            // Middle Section: Remaining & Next Installment Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "المتبقي:",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                    )
                    Text(
                        text = Formatter.formatCurrency(totalRemaining),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (totalRemaining > 0) DangerRed else TextDark,
                            fontSize = 14.sp
                        )
                    )
                }
                
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "القسط القادم:",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                    )
                    Text(
                        text = nextInstallmentStr,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.Medium,
                            color = DeepNavy
                        ),
                        maxLines = 1
                    )
                }
            }

            Divider(color = BorderLight.copy(alpha = 0.3f), thickness = 0.8.dp)

            // Bottom Section: Actions Row (اتصال، واتساب، تفاصيل، تعديل، وحذف)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Call Action (اتصال)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .background(DeepNavy.copy(alpha = 0.05f), RoundedCornerShape(8.dp))
                        .clickable {
                            try {
                                val callIntent = android.content.Intent(android.content.Intent.ACTION_DIAL, android.net.Uri.parse("tel:${customer.phone}"))
                                context.startActivity(callIntent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "لا يمكن إجراء المكالمة", Toast.LENGTH_SHORT).show()
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = "اتصال",
                            tint = DeepNavy,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "اتصال",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = DeepNavy
                            )
                        )
                    }
                }

                // WhatsApp Action (واتساب)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .background(SuccessGreen.copy(alpha = 0.05f), RoundedCornerShape(8.dp))
                        .clickable {
                            try {
                                val whatsappIntent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://api.whatsapp.com/send?phone=${customer.phone}"))
                                context.startActivity(whatsappIntent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "لا يمكن فتح واتساب", Toast.LENGTH_SHORT).show()
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Chat,
                            contentDescription = "واتساب",
                            tint = SuccessGreen,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "واتساب",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = SuccessGreen
                            )
                        )
                    }
                }

                // Details Action (تفاصيل)
                Box(
                    modifier = Modifier
                        .weight(1.2f)
                        .height(36.dp)
                        .background(DeepNavy, RoundedCornerShape(8.dp))
                        .clickable(onClick = onClick),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "تفاصيل",
                            tint = RoyalGold,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "تفاصيل",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = SoftSurface
                            )
                        )
                    }
                }

                // Edit Action (تعديل)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .background(RoyalGold.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                        .clickable(onClick = onClick),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "تعديل",
                            tint = DeepNavy,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "تعديل",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = DeepNavy
                            )
                        )
                    }
                }

                // Delete Action (حذف)
                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier
                        .size(36.dp)
                        .background(DangerRed.copy(alpha = 0.05f), RoundedCornerShape(8.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "حذف العميل",
                        tint = DangerRed,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}


// ==========================================
// 5. CUSTOMER DETAILS SCREEN (تفاصيل العميل)
// ==========================================
@Composable
fun CustomerDetailsScreen(viewModel: MainViewModel) {
    val customer by viewModel.selectedCustomer.collectAsState()
    val salesList by viewModel.selectedCustomerSales.collectAsState()
    val billsList by viewModel.selectedCustomerBills.collectAsState()
    val totalPaid by viewModel.selectedCustomerTotalPaid.collectAsState()
    val remainingAmount by viewModel.selectedCustomerRemainingAmount.collectAsState()
    val nextDueDate by viewModel.selectedCustomerNextDueDate.collectAsState()
    val nextDueDay by viewModel.selectedCustomerNextDueDay.collectAsState()
    val context = LocalContext.current

    if (customer == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = RoyalGold)
        }
        return
    }

    val currentCustomer = customer!!
    val currentSale = salesList.firstOrNull()

    // Date display helper replacing hyphen with slash
    fun formatDisplayDate(dateStr: String): String {
        return dateStr.replace("-", "/")
    }

    // Dialogue states for existing edit / delete flows
    var showDeleteConfirm by remember { mutableStateOf<InstallmentBill?>(null) }
    var showEditDialog by remember { mutableStateOf<InstallmentBill?>(null) }
    var editAmountText by remember { mutableStateOf("") }
    var editDateText by remember { mutableStateOf("") }
    var editNotesText by remember { mutableStateOf("") }

    // Screen-level state variables for adding a payment
    var payAmountText by remember { mutableStateOf("") }
    var payDateText by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var payNotesText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SoftBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. TOP HEADER BAR
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = { viewModel.currentScreen = AppScreen.CUSTOMERS },
                modifier = Modifier
                    .size(40.dp)
                    .background(Color.White, CircleShape)
                    .shadow(2.dp, CircleShape)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = DeepNavy
                )
            }
            
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "تفاصيل القسط",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = DeepNavy)
                )
                Text(
                    text = "المبيعات والأقساط",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconButton(
                    onClick = { /* no-op */ },
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color.White, CircleShape)
                        .shadow(2.dp, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "Notifications",
                        tint = DeepNavy
                    )
                }
                IconButton(
                    onClick = { /* no-op */ },
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color.White, CircleShape)
                        .shadow(2.dp, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "History",
                        tint = DeepNavy
                    )
                }
            }
        }

        // 2. CUSTOMER IDENTITY CARD
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = RoyalGold, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "اسم العميل: ${currentCustomer.name}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TextDark)
                    )
                }
                Divider(color = BorderLight)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = currentCustomer.phone, style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary))
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                val nextBill = billsList.filter { it.saleId == currentSale?.id && !it.isPaid }.sortedBy { it.dueDate }.firstOrNull()
                                if (nextBill != null) {
                                    val days = viewModel.nearDueDays
                                    val billStatus = getInstallmentStatus(nextBill.dueDate, days)
                                    com.example.utils.WhatsAppHelper.sendWhatsAppMessage(
                                        context = context,
                                        phone = currentCustomer.phone,
                                        status = billStatus,
                                        customerName = currentCustomer.name,
                                        dueDate = nextBill.dueDate,
                                        amount = nextBill.amount
                                    )
                                } else {
                                    try {
                                        val formatted = com.example.utils.WhatsAppHelper.formatIraqiPhoneNumber(currentCustomer.phone)
                                        val welcomeMsg = java.net.URLEncoder.encode("مرحباً أستاذ ${currentCustomer.name}، يسعدنا تواصلكم معنا.", "UTF-8")
                                        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                            data = android.net.Uri.parse("https://api.whatsapp.com/send?phone=$formatted&text=$welcomeMsg")
                                        }
                                        context.startActivity(intent)
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "فشل فتح تطبيق الواتساب", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "إرسال عبر الواتساب",
                                tint = Color(0xFF25D366),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    if (currentCustomer.nationalId.isNotEmpty()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Badge, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "الهوية: ${currentCustomer.nationalId}", style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary))
                        }
                    }
                }
            }
        }

        if (currentSale != null) {
            // 3. PRIMARY FINANCIAL INFO CARD (REPLICATING SCREENSHOT CARD 1)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderLight, RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Total Price
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "السعر الكلي للمادة:", style = MaterialTheme.typography.bodyLarge.copy(color = TextDark, fontWeight = FontWeight.Bold))
                        Text(text = Formatter.formatCurrency(currentSale.installmentPrice), style = MaterialTheme.typography.bodyLarge.copy(color = DeepNavy, fontWeight = FontWeight.Bold))
                    }
                    Divider(color = BorderLight.copy(alpha = 0.5f))

                    // Down Payment
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "المقدمة المدفوعة:", style = MaterialTheme.typography.bodyLarge.copy(color = TextDark, fontWeight = FontWeight.Bold))
                        Text(text = Formatter.formatCurrency(currentSale.downPayment), style = MaterialTheme.typography.bodyLarge.copy(color = DeepNavy, fontWeight = FontWeight.Bold))
                    }
                    Divider(color = BorderLight.copy(alpha = 0.5f))

                    // Monthly Installment
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "القسط الشهري المحدد:", style = MaterialTheme.typography.bodyLarge.copy(color = TextDark, fontWeight = FontWeight.Bold))
                        Text(text = Formatter.formatCurrency(currentSale.monthlyInstallment), style = MaterialTheme.typography.bodyLarge.copy(color = DeepNavy, fontWeight = FontWeight.Bold))
                    }

                    // Yellow Warning Box
                    val nextDueDateDisplay = if (remainingAmount <= 0.0) "لا يوجد استحقاق قادم" else formatDisplayDate(nextDueDate)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color(0xFFFDE047), RoundedCornerShape(12.dp)),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF9C3)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.CalendarMonth, contentDescription = null, tint = Color(0xFFCA8A04), modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "يوم السداد المحدد: يوم $nextDueDay في كل شهر",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = Color(0xFF854D0E), fontWeight = FontWeight.Bold)
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Event, contentDescription = null, tint = Color(0xFFCA8A04), modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "تاريخ الاستحقاق القادم: $nextDueDateDisplay",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = Color(0xFF854D0E), fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }

                    Divider(color = BorderLight.copy(alpha = 0.5f))

                    // Net Remaining Balance
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "المتبقي الصافي للذمة:", style = MaterialTheme.typography.titleMedium.copy(color = DangerRed, fontWeight = FontWeight.Bold))
                        Text(text = Formatter.formatCurrency(remainingAmount), style = MaterialTheme.typography.headlineSmall.copy(color = DangerRed, fontWeight = FontWeight.ExtraBold))
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Print Contract Invoice Button
                    OutlinedButton(
                        onClick = {
                            viewModel.printContract(context, currentSale, currentCustomer)
                        },
                        modifier = Modifier.fillMaxWidth().height(46.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = DeepNavy),
                        border = BorderStroke(1.5.dp, DeepNavy),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Print, contentDescription = null, tint = DeepNavy, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("طباعة فاتورة العقد الكاملة", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            // 4. ADD PAYMENT CARD (REPLICATING SCREENSHOT CARD 2)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, Color(0xFF86EFAC), RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.MonetizationOn,
                            contentDescription = null,
                            tint = Color(0xFF16A34A),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تسديد دفعة أو قسط جديد",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
                        )
                    }
                    Divider(color = Color(0xFFDCFCE7))

                    // Input Amount Label
                    Text(
                        text = "اكتب مبلغ الدفع بالدينار العراقي:",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextDark, fontWeight = FontWeight.Bold)
                    )

                    // Premium Text Field
                    PremiumTextField(
                        value = payAmountText,
                        onValueChange = { payAmountText = Formatter.updatePriceField(payAmountText, it) },
                        label = "مبلغ الدفعة الحالية *",
                        placeholder = "أدخل المبلغ بالدينار...",
                        leadingIcon = Icons.Default.Payments,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        isSuccess = Formatter.sanitizeAmount(payAmountText) > 0,
                        trailingIcon = { Text("د.ع", modifier = Modifier.padding(end = 12.dp), color = Color(0xFF16A34A), fontWeight = FontWeight.Bold) }
                    )

                    if (payAmountText.isNotEmpty()) {
                        Text(
                            text = "المبلغ المكتوب: " + Formatter.formatCurrency(Formatter.sanitizeAmount(payAmountText)),
                            style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF16A34A), fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Date Picker Label
                    Text(
                        text = "تاريخ تسجيل الدفع (تلقائي أو اختر يدوياً):",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextDark, fontWeight = FontWeight.Bold)
                    )

                    // Clickable Date Box
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                showDatePicker(context, payDateText) { selectedDate ->
                                    payDateText = selectedDate
                                }
                            }
                            .border(1.dp, BorderLight, RoundedCornerShape(12.dp)),
                        colors = CardDefaults.cardColors(containerColor = SoftSurface),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = formatDisplayDate(payDateText),
                                style = MaterialTheme.typography.bodyLarge.copy(color = TextDark, fontWeight = FontWeight.Bold)
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Select Date",
                                tint = TextSecondary
                            )
                        }
                    }

                    // Optional Notes Field
                    PremiumTextField(
                        value = payNotesText,
                        onValueChange = { payNotesText = it },
                        label = "ملاحظات الدفعة (اختياري)",
                        placeholder = "اكتب أي ملاحظات إضافية هنا...",
                        leadingIcon = Icons.Default.Notes
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Confirm Payment Button
                    Button(
                        onClick = {
                            val amount = Formatter.sanitizeAmount(payAmountText)
                            if (amount <= 0) {
                                Toast.makeText(context, "الرجاء إدخال مبلغ دفع صالح!", Toast.LENGTH_SHORT).show()
                            } else if (amount > remainingAmount + 0.01) {
                                Toast.makeText(context, "مبلغ الدفع أكبر من المتبقي الصافي للذمة", Toast.LENGTH_SHORT).show()
                            } else {
                                viewModel.addNewPayment(
                                    saleId = currentSale.id,
                                    customerId = currentCustomer.id,
                                    amount = amount,
                                    dateStr = payDateText,
                                    notes = payNotesText,
                                    onError = { errorMsg ->
                                        Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()
                                    },
                                    onSuccess = {
                                        Toast.makeText(context, "تم تسجيل الدفعة بنجاح!", Toast.LENGTH_SHORT).show()
                                        payAmountText = ""
                                        payNotesText = ""
                                    }
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تأكيد وتسجيل الدفعة الحالية", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }

            // 5. HISTORY OF PAID RECEIPTS / PAYMENTS SECTION (REPLICATING SCREENSHOT LIST)
            Text(
                text = "سجل الوصولات السابقة والمدفوعات",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepNavy),
                modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
            )

            val paidBills = billsList.filter { it.saleId == currentSale.id && it.isPaid }.sortedByDescending { it.paymentDate ?: it.dueDate }
            if (paidBills.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White, RoundedCornerShape(16.dp))
                        .border(1.dp, BorderLight, RoundedCornerShape(16.dp))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "لا توجد أي دفعات سابقة مسجلة حالياً.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                    )
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    paidBills.forEach { bill ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, BorderLight, RoundedCornerShape(16.dp)),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(16.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Date and Notes
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = formatDisplayDate(bill.paymentDate ?: bill.dueDate),
                                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = TextDark)
                                    )
                                    if (bill.notes.isNotEmpty()) {
                                        Text(
                                            text = bill.notes,
                                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                                        )
                                    }
                                }

                                // Right-side layout including action buttons and badge
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    // Reprint Receipt Button
                                    IconButton(
                                        onClick = {
                                            viewModel.printReceipt(context, bill, currentSale, currentCustomer, billsList)
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Print, contentDescription = "Print", tint = Color(0xFF10B981), modifier = Modifier.size(18.dp))
                                    }
                                    
                                    // Edit Payment Button
                                    IconButton(
                                        onClick = {
                                            editAmountText = Formatter.updatePriceField("", bill.amountPaid.toInt().toString())
                                            editDateText = bill.paymentDate ?: ""
                                            editNotesText = bill.notes
                                            showEditDialog = bill
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", tint = DeepNavy, modifier = Modifier.size(18.dp))
                                    }

                                    // Delete Payment Button
                                    IconButton(
                                        onClick = {
                                            showDeleteConfirm = bill
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = DangerRed, modifier = Modifier.size(18.dp))
                                    }
                                    
                                    Spacer(modifier = Modifier.width(8.dp))
                                    
                                    // Plus Green Badge
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFFDCFCE7))
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = "+ " + Formatter.formatCurrency(bill.amountPaid),
                                            color = Color(0xFF16A34A),
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Placeholder if no active sale found
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 40.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "لم يتم تسجيل أي مبيعات لهذا العميل حتى الآن.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                )
            }
        }

        Spacer(modifier = Modifier.height(100.dp))
    }

    // ==========================================
    // DIALOGS & SHEET ACTIONS FOR THE SCREEN
    // ==========================================

    // 1. EDIT PAYMENT DIALOG
    if (showEditDialog != null && currentSale != null) {
        val billToEdit = showEditDialog!!
        AlertDialog(
            onDismissRequest = { showEditDialog = null },
            confirmButton = {
                Button(
                    onClick = {
                        val amount = Formatter.sanitizeAmount(editAmountText)
                        if (amount <= 0) {
                            Toast.makeText(context, "الرجاء إدخال مبلغ دفع صالح!", Toast.LENGTH_SHORT).show()
                        } else {
                            viewModel.editPayment(
                                bill = billToEdit,
                                newAmount = amount,
                                newDate = editDateText,
                                newNotes = editNotesText,
                                onError = { errorMsg ->
                                    Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()
                                },
                                onSuccess = {
                                    Toast.makeText(context, "تم تعديل الدفعة بنجاح!", Toast.LENGTH_SHORT).show()
                                    showEditDialog = null
                                }
                            )
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeepNavy),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("حفظ التغييرات", color = SoftSurface, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = null }) {
                    Text("إلغاء", color = TextSecondary)
                }
            },
            title = {
                Text(
                    text = "تعديل دفعة مالية",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = DeepNavy)
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "تعديل بيانات عملية الدفع رقم #${billToEdit.id}",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                    )

                    PremiumTextField(
                        value = editAmountText,
                        onValueChange = { editAmountText = Formatter.updatePriceField(editAmountText, it) },
                        label = "مبلغ الدفعة (د.ع) *",
                        placeholder = "أدخل المبلغ المدفوع بالدينار العراقي...",
                        leadingIcon = Icons.Default.AttachMoney,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        isSuccess = Formatter.sanitizeAmount(editAmountText) > 0,
                        trailingIcon = { Text("د.ع", modifier = Modifier.padding(end = 12.dp), color = RoyalGold, fontWeight = FontWeight.Bold) }
                    )
                    if (editAmountText.isNotEmpty()) {
                        Text(
                            text = "المبلغ: " + Formatter.formatCurrency(Formatter.sanitizeAmount(editAmountText)),
                            style = MaterialTheme.typography.bodySmall.copy(color = SuccessGreen, fontWeight = FontWeight.Medium),
                            modifier = Modifier.padding(start = 8.dp, top = 2.dp)
                        )
                    }

                    PremiumTextField(
                        value = editDateText,
                        onValueChange = { editDateText = it },
                        label = "تاريخ الدفع (السنة-الشهر-اليوم) *",
                        placeholder = "YYYY-MM-DD",
                        leadingIcon = Icons.Default.CalendarToday,
                        readOnly = true,
                        isSuccess = editDateText.isNotEmpty(),
                        modifier = Modifier.clickable {
                            showDatePicker(context, editDateText) { selectedDate ->
                                editDateText = selectedDate
                            }
                        }
                    )

                    PremiumTextField(
                        value = editNotesText,
                        onValueChange = { editNotesText = it },
                        label = "ملاحظات (اختياري)",
                        placeholder = "مثلاً: تعديل المبلغ، ملاحظات إضافية...",
                        leadingIcon = Icons.Default.Edit
                    )
                }
            },
            shape = RoundedCornerShape(24.dp),
            containerColor = SoftSurface
        )
    }

    // 2. DELETE PAYMENT CONFIRM DIALOG
    if (showDeleteConfirm != null) {
        val billToDelete = showDeleteConfirm!!
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = null },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deletePayment(billToDelete)
                        Toast.makeText(context, "تم حذف الدفعة بنجاح!", Toast.LENGTH_SHORT).show()
                        showDeleteConfirm = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("نعم، احذف الدفعة", color = SoftSurface, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = null }) {
                    Text("إلغاء", color = TextSecondary)
                }
            },
            title = {
                Text(
                    text = "حذف الدفعة المالية",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = DangerRed)
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من حذف عملية الدفع رقم #${billToDelete.id} بقيمة ${Formatter.formatCurrency(billToDelete.amountPaid)}؟ سيتم إعادة حساب الرصيد المتبقي وحالة العقد تلقائياً بعد الحذف.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextDark)
                )
            },
            shape = RoundedCornerShape(24.dp),
            containerColor = SoftSurface
        )
    }
}

@Composable
fun FinancialRow(
    label: String,
    value: String,
    color: Color = TextDark,
    isBold: Boolean = false
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyLarge.copy(
                color = color,
                fontWeight = if (isBold) FontWeight.Bold else FontWeight.SemiBold
            )
        )
    }
}

@Composable
fun SubTabButton(title: String, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) SoftSurface else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = if (isSelected) DeepNavy else TextSecondary
            )
        )
    }
}

@Composable
fun ProfileRow(label: String, value: String) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary))
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, style = MaterialTheme.typography.bodyLarge.copy(color = TextDark, fontWeight = FontWeight.SemiBold))
        Divider(color = BorderLight, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
fun InstallmentScheduleCard(bill: InstallmentBill, onPay: () -> Unit) {
    val isOverdue = !bill.isPaid && isBillOverdue(bill.dueDate)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .border(
                width = 1.dp,
                color = if (bill.isPaid) BorderLight else if (isOverdue) DangerRed.copy(alpha = 0.5f) else WarningAmber.copy(alpha = 0.5f),
                shape = RoundedCornerShape(12.dp)
            ),
        colors = CardDefaults.cardColors(containerColor = SoftSurface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "القسط رقم ${bill.billNumber}",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TextDark)
                )
                Text(
                    text = "تاريخ الاستحقاق: ${bill.dueDate}",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = if (isOverdue) DangerRed else TextSecondary,
                        fontWeight = if (isOverdue) FontWeight.Bold else FontWeight.Normal
                    )
                )
                Text(
                    text = "القيمة: ${Formatter.formatCurrency(bill.amount)}",
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = DeepNavy)
                )
            }

            if (bill.isPaid) {
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(SuccessGreen.copy(alpha = 0.15f))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(text = "مدفوع", color = SuccessGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            } else {
                Button(
                    onClick = onPay,
                    colors = ButtonDefaults.buttonColors(containerColor = DeepNavy),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(text = "تسديد", color = SoftSurface, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun TimelinePaymentRow(bill: InstallmentBill) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .background(SuccessGreen, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = SoftSurface, modifier = Modifier.size(14.dp))
            }
            Box(
                modifier = Modifier
                    .width(2.dp)
                    .height(40.dp)
                    .background(BorderLight)
            )
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(
                text = "تم تسديد القسط رقم ${bill.billNumber}",
                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = TextDark)
            )
            Text(
                text = "تاريخ الدفع: ${bill.paymentDate ?: "غير معروف"}",
                style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
            )
            Text(
                text = "المبلغ المدفوع: ${Formatter.formatCurrency(bill.amountPaid)}",
                style = MaterialTheme.typography.bodyMedium.copy(color = SuccessGreen, fontWeight = FontWeight.Bold)
            )
        }
    }
}


// ==========================================
// 6. NOTIFICATIONS SCREEN (التنبيهات)
// ==========================================
@Composable
fun AlertsScreen(viewModel: MainViewModel) {
    val activeSubTab by viewModel.activeAlertTab.collectAsState()
    val tabCounts by viewModel.alertTabCounts.collectAsState()
    val displayAlerts by viewModel.alertUiStates.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "التنبيهات والأقساط المستحقة",
                style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold, color = TextDark, fontSize = 20.sp)
            )
        }

        // Tabs Row (الكل، يستحق، يقترب، متأخر)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    AlertTabButton(
                        title = "الكل",
                        count = tabCounts.all.toString(),
                        isSelected = activeSubTab == "ALL",
                        color = DeepNavy,
                        onClick = { viewModel.activeAlertTab.value = "ALL" }
                    )
                }
                Box(modifier = Modifier.weight(1f)) {
                    AlertTabButton(
                        title = "يستحق",
                        count = tabCounts.today.toString(),
                        isSelected = activeSubTab == "TODAY",
                        color = Color(0xFFF97316),
                        onClick = { viewModel.activeAlertTab.value = "TODAY" }
                    )
                }
                Box(modifier = Modifier.weight(1f)) {
                    AlertTabButton(
                        title = "يقترب",
                        count = tabCounts.near.toString(),
                        isSelected = activeSubTab == "NEAR",
                        color = Color(0xFFEAB308),
                        onClick = { viewModel.activeAlertTab.value = "NEAR" }
                    )
                }
                Box(modifier = Modifier.weight(1f)) {
                    AlertTabButton(
                        title = "متأخر",
                        count = tabCounts.overdue.toString(),
                        isSelected = activeSubTab == "OVERDUE",
                        color = DangerRed,
                        onClick = { viewModel.activeAlertTab.value = "OVERDUE" }
                    )
                }
            }
        }

        if (displayAlerts.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 80.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        PremiumEmptyIllustration()
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = "لا توجد أي تنبيهات معلقة هنا!",
                            style = MaterialTheme.typography.titleMedium.copy(color = TextDark, fontWeight = FontWeight.Bold),
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "كل شيء منظم ومحدث بنجاح في هذا التبويب",
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            }
        } else {
            items(displayAlerts, key = { it.bill.id }) { state ->
                AlertBillCard(
                    bill = state.bill,
                    customerName = state.customerName,
                    customerPhone = state.customerPhone,
                    status = state.status,
                    onClick = {
                        viewModel.selectedCustomerId.value = state.bill.customerId
                        viewModel.currentScreen = AppScreen.CUSTOMER_DETAILS
                    }
                )
            }
        }
    }
}

@Composable
fun AlertTabButton(title: String, count: String, isSelected: Boolean, color: Color, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) color else BorderLight,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) color.copy(alpha = 0.05f) else SoftSurface
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = if (isSelected) color else TextDark))
            Spacer(modifier = Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .background(color = color, shape = CircleShape)
                    .padding(horizontal = 8.dp, vertical = 2.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(text = count, color = SoftSurface, style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
            }
        }
    }
}

@Composable
fun AlertBillCard(
    bill: InstallmentBill,
    customerName: String,
    customerPhone: String,
    status: InstallmentStatus,
    onClick: () -> Unit
) {
    val icon = when (status) {
        InstallmentStatus.OVERDUE -> Icons.Default.PriorityHigh
        InstallmentStatus.DUE -> Icons.Default.Notifications
        else -> Icons.Default.CalendarToday
    }

    val statusText = when (status) {
        InstallmentStatus.OVERDUE -> "متأخر"
        InstallmentStatus.DUE -> "مستحق"
        InstallmentStatus.NEAR -> "اقترب"
        else -> ""
    }

    val statusBgColor = when (status) {
        InstallmentStatus.OVERDUE -> DangerRed.copy(alpha = 0.15f)
        InstallmentStatus.DUE -> Color(0xFFF97316).copy(alpha = 0.15f)
        InstallmentStatus.NEAR -> Color(0xFFEAB308).copy(alpha = 0.15f)
        else -> TextSecondary.copy(alpha = 0.12f)
    }

    val statusColor = when (status) {
        InstallmentStatus.OVERDUE -> DangerRed
        InstallmentStatus.DUE -> Color(0xFFF97316)
        InstallmentStatus.NEAR -> Color(0xFFEAB308)
        else -> TextSecondary
    }

    val iconTint = when (status) {
        InstallmentStatus.OVERDUE -> DangerRed
        InstallmentStatus.DUE -> Color(0xFFF97316)
        InstallmentStatus.NEAR -> Color(0xFFEAB308)
        else -> TextSecondary
    }

    val context = LocalContext.current

    PremiumCard {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(iconTint.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = customerName,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TextDark)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "القسط ${bill.billNumber} • موعده: ${bill.dueDate}",
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(statusBgColor)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = statusText,
                                color = statusColor,
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = {
                        com.example.utils.WhatsAppHelper.sendWhatsAppMessage(
                            context = context,
                            phone = customerPhone,
                            status = status,
                            customerName = customerName,
                            dueDate = bill.dueDate,
                            amount = bill.amount
                        )
                    },
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "إرسال تذكير عبر الواتساب",
                        tint = Color(0xFF25D366),
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = Formatter.formatCurrency(bill.amount),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepNavy)
                    )
                    Text(text = "عرض التفاصيل", style = MaterialTheme.typography.labelSmall.copy(color = RoyalGold, fontWeight = FontWeight.Bold))
                }
            }
        }
    }
}

// Draw a beautiful custom offline financial vector illustration for empty alert tab
@Composable
fun PremiumEmptyIllustration() {
    Canvas(
        modifier = Modifier
            .size(160.dp)
    ) {
        val center = Offset(size.width / 2, size.height / 2)
        
        // Draw decorative concentric rings
        drawCircle(
            color = RoyalGold.copy(alpha = 0.08f),
            radius = 70.dp.toPx(),
            center = center
        )
        drawCircle(
            color = DeepNavy.copy(alpha = 0.05f),
            radius = 50.dp.toPx(),
            center = center
        )
        
        // Draw a neat gold coin with checking checkmark
        drawCircle(
            color = RoyalGold,
            radius = 30.dp.toPx(),
            center = center
        )
        
        // Draw inner golden pattern
        drawCircle(
            color = DeepNavy,
            radius = 26.dp.toPx(),
            center = center
        )

        // Draw check symbol in gold coin center
        val checkPath = Path().apply {
            moveTo(center.x - 10.dp.toPx(), center.y)
            lineTo(center.x - 2.dp.toPx(), center.y + 8.dp.toPx())
            lineTo(center.x + 12.dp.toPx(), center.y - 8.dp.toPx())
        }
        drawPath(
            path = checkPath,
            color = RoyalGold,
            style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
        )
    }
}


// ==========================================
// 7. SETTINGS SCREEN (الإعدادات)
// ==========================================
@Composable
fun SettingsScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    var isEditingName by remember { mutableStateOf(false) }
    var tempName by remember { mutableStateOf(viewModel.storeName) }

    val printerManager = remember { com.example.utils.BluetoothPrinterManager.getInstance(context) }
    val isConnected by printerManager.isConnected.collectAsState()
    val isConnecting by printerManager.isConnecting.collectAsState()
    val connectionStatus by printerManager.connectionStatus.collectAsState()
    val pairedDevices by printerManager.pairedDevices.collectAsState()
    val discoveredDevices by printerManager.discoveredDevices.collectAsState()
    val isScanning by printerManager.isScanning.collectAsState()
    
    var hasPermission by remember { mutableStateOf(printerManager.checkBluetoothPermissions()) }
    
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        hasPermission = permissions.values.all { it }
        if (hasPermission) {
            printerManager.updatePairedDevices()
        }
    }

    val bluetoothPermissions = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
        arrayOf(android.Manifest.permission.BLUETOOTH_CONNECT, android.Manifest.permission.BLUETOOTH_SCAN)
    } else {
        arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION)
    }

    val fileChooserLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            try {
                val tempFile = File(context.cacheDir, "temp_import.zip")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    tempFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }
                viewModel.importBackup(context, tempFile, {
                    Toast.makeText(context, "تم استيراد قاعدة البيانات بنجاح!", Toast.LENGTH_LONG).show()
                }, { error ->
                    Toast.makeText(context, "خطأ الاستيراد: $error", Toast.LENGTH_LONG).show()
                })
            } catch (e: Exception) {
                Toast.makeText(context, "حدث خطأ أثناء قراءة الملف", Toast.LENGTH_SHORT).show()
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "إعدادات التطبيق",
                style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold, color = TextDark)
            )
        }

        // Store Name section Card
        item {
            PremiumCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "اسم المتجر الحالي (محدد من ملف coco)",
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                        )
                        Text(
                            text = viewModel.storeName,
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = TextDark),
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        }

        // Configurable Warning Days Card
        item {
            PremiumCard {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "تنبيهات اقتراب موعد الاستحقاق",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepNavy)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "حدد عدد الأيام المسبقة التي ترغب بظهور شارة (اقترب) فيها قبل موعد الاستحقاق.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    var sliderValue by remember { mutableStateOf(viewModel.nearDueDays.toFloat()) }
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "فترة التنبيه المسبق:",
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextDark)
                        )
                        Text(
                            text = "${sliderValue.toInt()} أيام",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepNavy)
                        )
                    }
                    
                    Slider(
                        value = sliderValue,
                        onValueChange = {
                            sliderValue = it
                            viewModel.updateNearDueDays(it.toInt())
                        },
                        valueRange = 1f..30f,
                        steps = 28,
                        colors = SliderDefaults.colors(
                            thumbColor = DeepNavy,
                            activeTrackColor = DeepNavy,
                            inactiveTrackColor = BorderLight
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        if (viewModel.isTrial) {
            item {
                PremiumCard {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "حالة الترخيص (فترة تجريبية)",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = WarningAmber)
                            )
                            Text(
                                text = viewModel.trialTimeRemainingString,
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary),
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        // Backup and Restore Card
        if (!viewModel.isTrial) {
            item {
                PremiumCard {
                    Text(
                        text = "النسخ الاحتياطي والأمان",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepNavy),
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    SettingsActionRow(
                        title = "تصدير نسخة احتياطية ZIP",
                        subtitle = "حفظ جميع المبيعات والأقساط في ملف ZIP مشارك",
                        icon = Icons.Default.CloudUpload,
                        onClick = {
                            viewModel.exportBackup(context, { backupFile ->
                                shareFile(context, backupFile)
                            }, { error ->
                                Toast.makeText(context, error, Toast.LENGTH_SHORT).show()
                            })
                        }
                    )

                    SettingsActionRow(
                        title = "استيراد نسخة احتياطية ZIP",
                        subtitle = "استرجاع بيانات المتجر والعملاء بالكامل",
                        icon = Icons.Default.CloudDownload,
                        onClick = {
                            fileChooserLauncher.launch("application/zip")
                        }
                    )
                }
            }
        }

        // Bluetooth Printer Management Card
        item {
            PremiumCard {
                Text(
                    text = "إعدادات الطابعة الحرارية Bluetooth",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepNavy),
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // Status indicator
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("حالة الاتصال:", style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(if (isConnected) Color(0xFF2ECC71) else if (isConnecting) RoyalGold else TextSecondary, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = connectionStatus,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = if (isConnected) Color(0xFF2ECC71) else TextDark)
                        )
                    }
                }

                if (isConnected) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = { printerManager.disconnect() },
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("قطع الاتصال")
                        }
                    }
                }

                HorizontalDivider(color = SoftBackground.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 8.dp))

                // Saved/Current Configuration
                var selectedSize by remember { mutableStateOf(printerManager.getSavedPrinterSize()) }
                var selectedCodepage by remember { mutableStateOf(printerManager.getSavedPrinterCodepage()) }

                Text("حجم الورق", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = TextDark))
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("58mm", "80mm").forEach { size ->
                        val active = selectedSize == size
                        Button(
                            onClick = {
                                selectedSize = size
                                val mac = printerManager.getSavedPrinterMac() ?: ""
                                val name = printerManager.getSavedPrinterName() ?: ""
                                printerManager.savePrinterConfig(mac, name, size, selectedCodepage)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (active) DeepNavy else SoftBackground,
                                contentColor = if (active) Color.White else TextDark
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(size)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text("ترميز الحروف (Codepage)", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = TextDark))
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("CP1256", "CP864", "UTF-8").forEach { cp ->
                        val active = selectedCodepage == cp
                        Button(
                            onClick = {
                                selectedCodepage = cp
                                val mac = printerManager.getSavedPrinterMac() ?: ""
                                val name = printerManager.getSavedPrinterName() ?: ""
                                printerManager.savePrinterConfig(mac, name, selectedSize, cp)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (active) DeepNavy else SoftBackground,
                                contentColor = if (active) Color.White else TextDark
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(cp)
                        }
                    }
                }

                HorizontalDivider(color = SoftBackground.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 8.dp))

                Text(
                    text = "خيارات تخصيص الطباعة المتقدمة (أوفلاين)",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = DeepNavy),
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                // 1. Threshold / Contrast Slider
                var thresholdVal by remember { mutableStateOf(printerManager.getSavedPrinterThreshold().toFloat()) }
                Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("درجة وضوح وسمك الخط (التباين):", style = MaterialTheme.typography.bodySmall.copy(color = TextDark))
                        Text(
                            text = "${((thresholdVal - 80) / 100 * 100).toInt()}%",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = DeepNavy)
                        )
                    }
                    Slider(
                        value = thresholdVal,
                        onValueChange = {
                            thresholdVal = it
                            printerManager.savePrinterThreshold(it.toInt())
                        },
                        valueRange = 80f..180f,
                        colors = SliderDefaults.colors(
                            thumbColor = DeepNavy,
                            activeTrackColor = DeepNavy,
                            inactiveTrackColor = SoftBackground
                        )
                    )
                }

                // 2. Lateral Margins Slider
                var marginVal by remember { mutableStateOf(printerManager.getSavedPrinterMargin().toFloat()) }
                Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("الهوامش الجانبية (بكسل):", style = MaterialTheme.typography.bodySmall.copy(color = TextDark))
                        Text(
                            text = "${marginVal.toInt()} بكسل",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = DeepNavy)
                        )
                    }
                    Slider(
                        value = marginVal,
                        onValueChange = {
                            marginVal = it
                            printerManager.savePrinterMargin(it.toInt())
                        },
                        valueRange = 0f..40f,
                        colors = SliderDefaults.colors(
                            thumbColor = DeepNavy,
                            activeTrackColor = DeepNavy,
                            inactiveTrackColor = SoftBackground
                        )
                    )
                }

                // 3. Paper Feed Slider
                var feedLinesVal by remember { mutableStateOf(printerManager.getSavedPrinterFeed().toFloat()) }
                Column(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("تغذية أسطر الورق الفارغة بالخاتمة:", style = MaterialTheme.typography.bodySmall.copy(color = TextDark))
                        Text(
                            text = "${feedLinesVal.toInt()} أسطر",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = DeepNavy)
                        )
                    }
                    Slider(
                        value = feedLinesVal,
                        onValueChange = {
                            feedLinesVal = it
                            printerManager.savePrinterFeed(it.toInt())
                        },
                        valueRange = 0f..10f,
                        colors = SliderDefaults.colors(
                            thumbColor = DeepNavy,
                            activeTrackColor = DeepNavy,
                            inactiveTrackColor = SoftBackground
                        )
                    )
                }

                HorizontalDivider(color = SoftBackground.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 8.dp))

                if (!hasPermission) {
                    Button(
                        onClick = { permissionLauncher.launch(bluetoothPermissions) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalGold)
                    ) {
                        Text("منح صلاحيات البلوتوث والطباعة", color = DeepNavy, fontWeight = FontWeight.Bold)
                    }
                } else {
                    // Test print button
                    Button(
                        onClick = { printerManager.printTestReceipt() },
                        enabled = isConnected,
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2ECC71), contentColor = Color.White)
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("طباعة فاتورة تجريبية", fontWeight = FontWeight.Bold)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("البحث عن أجهزة", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = DeepNavy))
                        Button(
                            onClick = {
                                printerManager.startDiscovery()
                            },
                            enabled = !isScanning,
                            colors = ButtonDefaults.buttonColors(containerColor = DeepNavy)
                        ) {
                            Text(if (isScanning) "جاري البحث..." else "ابدأ البحث")
                        }
                    }

                    if (isScanning) {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), color = RoyalGold)
                    }

                    // Paired Devices
                    if (pairedDevices.isNotEmpty()) {
                        Text(
                            text = "الأجهزة المقترنة مسبقاً:",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                        )
                        pairedDevices.forEach { dev ->
                            val isSaved = dev.address == printerManager.getSavedPrinterMac()
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        printerManager.savePrinterConfig(dev.address, dev.name ?: dev.address, selectedSize, selectedCodepage)
                                        printerManager.connect(dev.address) { success, msg ->
                                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                    .padding(vertical = 8.dp, horizontal = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(dev.name ?: "جهاز غير معروف", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = TextDark))
                                    Text(dev.address, style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary))
                                }
                                if (isSaved) {
                                    Text("الافتراضية", style = MaterialTheme.typography.bodySmall.copy(color = RoyalGold, fontWeight = FontWeight.Bold))
                                }
                            }
                        }
                    }

                    // Discovered Devices
                    if (discoveredDevices.isNotEmpty()) {
                        Text(
                            text = "الأجهزة المكتشفة القريبة:",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                        )
                        discoveredDevices.forEach { dev ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        printerManager.stopDiscovery()
                                        printerManager.savePrinterConfig(dev.address, dev.name ?: dev.address, selectedSize, selectedCodepage)
                                        printerManager.connect(dev.address) { success, msg ->
                                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                    .padding(vertical = 8.dp, horizontal = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(dev.name ?: "جهاز بلوتوث", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = TextDark))
                                    Text(dev.address, style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary))
                                }
                                Icon(Icons.Default.Add, contentDescription = "Connect", tint = DeepNavy)
                            }
                        }
                    } else if (!isScanning) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "لا توجد طابعة قريبة",
                                style = MaterialTheme.typography.bodyMedium.copy(color = DangerRed, fontWeight = FontWeight.Bold)
                            )
                            Button(
                                onClick = {
                                    printerManager.startDiscovery()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DeepNavy)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, tint = SoftSurface)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("البحث مجددا", color = SoftSurface, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // About the App details
        item {
            PremiumCard {
                Text(
                    text = "حول نظام المبيعات والأقساط",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DeepNavy),
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                
                ProfileRow(label = "نسخة التطبيق:", value = "V 1.0.0 Premium")
                ProfileRow(label = "حالة قاعدة البيانات:", value = "متصلة بالكامل ومحفوظة محلياً (Room Database)")
                ProfileRow(label = "سياسة الخصوصية:", value = "أوفلاين بالكامل 100% ولا يتم جمع أو نقل أي بيانات خارج جهازك الشخصي.")
            }
        }

        // Log Out Card
        item {
            PremiumCard(
                onClick = {
                    viewModel.performLogout()
                }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.ExitToApp,
                        contentDescription = "تسجيل الخروج",
                        tint = DangerRed,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "تسجيل الخروج من النظام",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = DangerRed)
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsActionRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            PremiumIconWrapper(
                icon = icon,
                tint = RoyalGold,
                backgroundColor = DeepNavy.copy(alpha = 0.05f),
                size = 46
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(text = title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = TextDark))
                Text(text = subtitle, style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary))
            }
        }
        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = TextSecondary)
    }
}


// ==========================================
// HELPERS & DATES
// ==========================================
fun showDatePicker(context: android.content.Context, currentVal: String, onDateSelected: (String) -> Unit) {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val cal = Calendar.getInstance()
    try {
        val d = sdf.parse(currentVal)
        if (d != null) cal.time = d
    } catch (e: Exception) {
        // use today
    }

    DatePickerDialog(
        context,
        { _, year, month, dayOfMonth ->
            val selCal = Calendar.getInstance()
            selCal.set(Calendar.YEAR, year)
            selCal.set(Calendar.MONTH, month)
            selCal.set(Calendar.DAY_OF_MONTH, dayOfMonth)
            onDateSelected(sdf.format(selCal.time))
        },
        cal.get(Calendar.YEAR),
        cal.get(Calendar.MONTH),
        cal.get(Calendar.DAY_OF_MONTH)
    ).show()
}

fun isBillOverdue(dueDateStr: String): Boolean {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val todayStr = sdf.format(Date())
    return try {
        val dueDate = sdf.parse(dueDateStr)
        val today = sdf.parse(todayStr)
        dueDate != null && today != null && dueDate.before(today)
    } catch (e: Exception) {
        false
    }
}

fun isUpcomingWithinAWeek(dueDateStr: String): Boolean {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val todayStr = sdf.format(Date())
    return try {
        val dueDate = sdf.parse(dueDateStr)
        val today = sdf.parse(todayStr)
        if (dueDate != null && today != null) {
            val diff = dueDate.time - today.time
            diff > 0 && diff <= 7 * 24 * 60 * 60 * 1000L
        } else {
            false
        }
    } catch (e: Exception) {
        false
    }
}

fun shareFile(context: android.content.Context, file: File) {
    val uri = androidx.core.content.FileProvider.getUriForFile(
        context,
        "${context.packageName}.provider",
        file
    )
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "application/zip"
        putExtra(android.content.Intent.EXTRA_STREAM, uri)
        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(android.content.Intent.createChooser(intent, "تصدير قاعدة بيانات متجري"))
}
