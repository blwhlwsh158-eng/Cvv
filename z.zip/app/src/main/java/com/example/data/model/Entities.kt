package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Index

@Entity(
    tableName = "customers",
    indices = [
        Index(value = ["name"]),
        Index(value = ["phone"])
    ]
)
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String,
    val job: String,
    val nationalId: String,
    val province: String,
    val nearestLandmark: String,
    val registrationDate: String,
    val hasGuarantor: Boolean,
    val guarantorName: String = "",
    val guarantorPhone: String = "",
    val guarantorJob: String = "",
    val guarantorNationalId: String = ""
)

@Entity(
    tableName = "sales",
    indices = [
        Index(value = ["customerId"]),
        Index(value = ["status"])
    ]
)
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val itemName: String,
    val itemDescription: String,
    val cashPrice: Double,
    val installmentPrice: Double,
    val downPayment: Double,
    val monthsCount: Int,
    val monthlyInstallment: Double,
    val dueDay: Int,
    val firstDueDate: String,
    val saleDate: String,
    val status: String = "ACTIVE" // ACTIVE, COMPLETED
)

@Entity(
    tableName = "installment_bills",
    indices = [
        Index(value = ["saleId"]),
        Index(value = ["customerId"]),
        Index(value = ["dueDate"]),
        Index(value = ["isPaid"])
    ]
)
data class InstallmentBill(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val customerId: Long,
    val billNumber: Int, // e.g., 1 of 12
    val dueDate: String, // "YYYY-MM-DD"
    val amount: Double,
    val amountPaid: Double = 0.0,
    val paymentDate: String? = null,
    val isPaid: Boolean = false,
    val notes: String = ""
)

