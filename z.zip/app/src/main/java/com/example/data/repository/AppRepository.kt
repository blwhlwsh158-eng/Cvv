package com.example.data.repository

import com.example.data.db.CustomerDao
import com.example.data.db.InstallmentBillDao
import com.example.data.db.SaleDao
import com.example.data.model.Customer
import com.example.data.model.InstallmentBill
import com.example.data.model.Sale
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.text.SimpleDateFormat
import java.util.*

class AppRepository(
    private val customerDao: CustomerDao,
    private val saleDao: SaleDao,
    private val installmentBillDao: InstallmentBillDao
) {
    fun getAllCustomers(): Flow<List<Customer>> = customerDao.getAllCustomers()
    suspend fun getCustomerById(id: Long): Customer? = customerDao.getCustomerById(id)
    fun getCustomerByIdFlow(id: Long): Flow<Customer?> = customerDao.getCustomerByIdFlow(id)
    suspend fun insertCustomer(customer: Customer): Long = customerDao.insertCustomer(customer)
    suspend fun updateCustomer(customer: Customer) = customerDao.updateCustomer(customer)
    suspend fun deleteCustomer(customer: Customer) = customerDao.deleteCustomer(customer)

    fun getAllSales(): Flow<List<Sale>> = saleDao.getAllSales()
    suspend fun getSaleById(id: Long): Sale? = saleDao.getSaleById(id)
    fun getSalesByCustomerId(customerId: Long): Flow<List<Sale>> = saleDao.getSalesByCustomerId(customerId)
    
    suspend fun insertSale(sale: Sale, bills: List<InstallmentBill>): Long {
        val saleId = saleDao.insertSale(sale)
        val updatedBills = bills.map { it.copy(saleId = saleId) }
        installmentBillDao.insertBills(updatedBills)
        return saleId
    }
    
    suspend fun updateSale(sale: Sale) = saleDao.updateSale(sale)
    suspend fun deleteSale(sale: Sale) {
        saleDao.deleteSale(sale)
        installmentBillDao.deleteBillsBySaleId(sale.id)
    }

    fun getAllBills(): Flow<List<InstallmentBill>> = installmentBillDao.getAllBills()
    fun getBillsBySaleId(saleId: Long): Flow<List<InstallmentBill>> = installmentBillDao.getBillsBySaleId(saleId)
    fun getBillsByCustomerId(customerId: Long): Flow<List<InstallmentBill>> = installmentBillDao.getBillsByCustomerId(customerId)
    suspend fun updateBill(bill: InstallmentBill) = installmentBillDao.updateBill(bill)
    suspend fun insertBills(bills: List<InstallmentBill>) = installmentBillDao.insertBills(bills)
    suspend fun deleteBill(bill: InstallmentBill) = installmentBillDao.deleteBill(bill)
    suspend fun deleteBillsBySaleId(saleId: Long) = installmentBillDao.deleteBillsBySaleId(saleId)

    suspend fun clearAllData() {
        customerDao.deleteAllCustomers()
        saleDao.deleteAllSales()
        installmentBillDao.deleteAllBills()
    }

    // Prepopulate database with premium sample data if empty
    suspend fun prepopulateIfEmpty() {
        // Disabled to keep the app completely empty of dummy data
    }
}
