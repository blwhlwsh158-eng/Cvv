package com.example.utils

import java.lang.StringBuilder

object ArabicPrinterHelper {

    private class ArabicChar(
        val unicode: Char,
        val isolated: Char,
        val initial: Char,
        val medial: Char,
        val final: Char
    )

    private val leftConnectors = setOf(
        'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'ي', 'ئ', 'ى'
    )

    private val rightConnectors = setOf(
        'آ', 'أ', 'ؤ', 'إ', 'ا', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز', 'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ي', 'ى', 'ة'
    )

    private val charMap = mapOf(
        'ء' to ArabicChar('ء', '\uFE80', '\uFE80', '\uFE80', '\uFE80'),
        'آ' to ArabicChar('آ', '\uFE81', '\uFE81', '\uFE82', '\uFE82'),
        'أ' to ArabicChar('أ', '\uFE83', '\uFE83', '\uFE84', '\uFE84'),
        'ؤ' to ArabicChar('ؤ', '\uFE85', '\uFE85', '\uFE86', '\uFE86'),
        'إ' to ArabicChar('إ', '\uFE87', '\uFE87', '\uFE88', '\uFE88'),
        'ئ' to ArabicChar('ئ', '\uFE89', '\uFE8B', '\uFE8C', '\uFE8A'),
        'ا' to ArabicChar('ا', '\uFE8D', '\uFE8D', '\uFE8E', '\uFE8E'),
        'ب' to ArabicChar('ب', '\uFE8F', '\uFE91', '\uFE92', '\uFE90'),
        'ة' to ArabicChar('ة', '\uFE93', '\uFE93', '\uFE94', '\uFE94'),
        'ت' to ArabicChar('ت', '\uFE95', '\uFE97', '\uFE98', '\uFE96'),
        'ث' to ArabicChar('ث', '\uFE99', '\uFE9B', '\uFE9C', '\uFE9A'),
        'ج' to ArabicChar('ج', '\uFE9D', '\uFE9F', '\uFEA0', '\uFE9E'),
        'ح' to ArabicChar('ح', '\uFEA1', '\uFEA3', '\uFEA4', '\uFEA2'),
        'خ' to ArabicChar('خ', '\uFEA5', '\uFEA7', '\uFEA8', '\uFEA6'),
        'د' to ArabicChar('د', '\uFEA9', '\uFEA9', '\uFEAA', '\uFEAA'),
        'ذ' to ArabicChar('ذ', '\uFEAB', '\uFEAB', '\uFEAC', '\uFEAC'),
        'ر' to ArabicChar('ر', '\uFEAD', '\uFEAD', '\uFEAE', '\uFEAE'),
        'ز' to ArabicChar('ز', '\uFEAF', '\uFEAF', '\uFEB0', '\uFEB0'),
        'س' to ArabicChar('س', '\uFEB1', '\uFEB3', '\uFEB4', '\uFEB2'),
        'ش' to ArabicChar('ش', '\uFEB5', '\uFEB7', '\uFEB8', '\uFEB6'),
        'ص' to ArabicChar('ص', '\uFEB9', '\uFEBB', '\uFEBC', '\uFEBA'),
        'ض' to ArabicChar('ض', '\uFEBD', '\uFEBF', '\uFEC0', '\uFEBE'),
        'ط' to ArabicChar('ط', '\uFEC1', '\uFEC3', '\uFEC4', '\uFEC2'),
        'ظ' to ArabicChar('ظ', '\uFEC5', '\uFEC7', '\uFEC8', '\uFEC6'),
        'ع' to ArabicChar('ع', '\uFEC9', '\uFECB', '\uFECC', '\uFECA'),
        'غ' to ArabicChar('غ', '\uFECD', '\uFECF', '\uFED0', '\uFECE'),
        'ف' to ArabicChar('ف', '\uFED1', '\uFED3', '\uFED4', '\uFED2'),
        'ق' to ArabicChar('ق', '\uFED5', '\uFED7', '\uFED8', '\uFED6'),
        'ك' to ArabicChar('ك', '\uFED9', '\uFEDB', '\uFEDC', '\uFEDA'),
        'ل' to ArabicChar('ل', '\uFEDD', '\uFEDF', '\uFEE0', '\uFEDE'),
        'م' to ArabicChar('م', '\uFEE1', '\uFEE3', '\uFEE4', '\uFEE2'),
        'ن' to ArabicChar('ن', '\uFEE5', '\uFEE7', '\uFEE8', '\uFEE6'),
        'ه' to ArabicChar('ه', '\uFEE9', '\uFEEB', '\uFEEC', '\uFEEA'),
        'و' to ArabicChar('و', '\uFEED', '\uFEED', '\uFEEE', '\uFEEE'),
        'ى' to ArabicChar('ى', '\uFEEF', '\uFEEF', '\uFEF0', '\uFEF0'),
        'ي' to ArabicChar('ي', '\uFEF1', '\uFEF3', '\uFEF4', '\uFEF2')
    )

    fun reshape(text: String): String {
        if (text.isEmpty()) return text
        
        // 1. Preprocess Lam-Alef ligatures
        val processedText = StringBuilder()
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (c == 'ل' && i + 1 < text.length) {
                val nextC = text[i + 1]
                val prevC = if (processedText.isNotEmpty()) processedText.last() else null
                val prevConnects = prevC != null && leftConnectors.contains(prevC)
                
                val lamAlefChar = when (nextC) {
                    'ا' -> if (prevConnects) '\uFEFC' else '\uFEFB'
                    'أ' -> if (prevConnects) '\uFEF8' else '\uFEF7'
                    'إ' -> if (prevConnects) '\uFEFA' else '\uFEF9'
                    'آ' -> if (prevConnects) '\uFEF6' else '\uFEF5'
                    else -> null
                }
                
                if (lamAlefChar != null) {
                    processedText.append(lamAlefChar)
                    i += 2
                    continue
                }
            }
            processedText.append(c)
            i++
        }
        
        val t = processedText.toString()
        val result = StringBuilder()
        for (idx in t.indices) {
            val c = t[idx]
            val arabicChar = charMap[c]
            if (arabicChar == null) {
                result.append(c)
                continue
            }
            
            val prevC = if (idx > 0) t[idx - 1] else null
            val nextC = if (idx < t.length - 1) t[idx + 1] else null
            
            val connectsRight = prevC != null && leftConnectors.contains(prevC) && rightConnectors.contains(c)
            val connectsLeft = nextC != null && rightConnectors.contains(nextC) && leftConnectors.contains(c)
            
            val shaped = when {
                connectsRight && connectsLeft -> arabicChar.medial
                connectsRight -> arabicChar.final
                connectsLeft -> arabicChar.initial
                else -> arabicChar.isolated
            }
            result.append(shaped)
        }
        return result.toString()
    }

    // Check if character is Arabic
    private fun isArabicChar(c: Char): Boolean {
        return c in '\u0600'..'\u06FF' || c in '\uFE70'..'\uFEFF'
    }

    // Reverses Arabic segments in a line of text while preserving number/Latin segments LTR
    fun formatLineArabicRTL(line: String): String {
        if (line.isEmpty()) return line
        
        // Shape Arabic letters first
        val shapedLine = reshape(line)
        
        // Tokenize line into segments of same directionality
        val tokens = mutableListOf<String>()
        val tokenTypes = mutableListOf<Boolean>() // true for Arabic, false for other
        
        var currentToken = StringBuilder()
        var isCurrentArabic = isArabicChar(shapedLine[0])
        
        for (c in shapedLine) {
            val isCArabic = isArabicChar(c)
            if (isCArabic == isCurrentArabic) {
                currentToken.append(c)
            } else {
                tokens.add(currentToken.toString())
                tokenTypes.add(isCurrentArabic)
                currentToken = StringBuilder().append(c)
                isCurrentArabic = isCArabic
            }
        }
        if (currentToken.isNotEmpty()) {
            tokens.add(currentToken.toString())
            tokenTypes.add(isCurrentArabic)
        }
        
        // Construct visual LTR representation for printer:
        // Arabic words are reversed internally (so printer's LTR sweeps it RTL)
        // Order of tokens is reversed so that line flows from right to left
        val result = StringBuilder()
        for (idx in tokens.indices.reversed()) {
            val token = tokens[idx]
            val isArabic = tokenTypes[idx]
            if (isArabic) {
                result.append(token.reversed())
            } else {
                result.append(token)
            }
        }
        
        return result.toString()
    }

    // Align a line to full width
    fun alignCenter(text: String, width: Int): String {
        val rtlText = formatLineArabicRTL(text)
        if (rtlText.length >= width) return rtlText.substring(0, width)
        val padding = (width - rtlText.length) / 2
        return " ".repeat(padding) + rtlText + " ".repeat(width - rtlText.length - padding)
    }

    fun alignRight(text: String, width: Int): String {
        val rtlText = formatLineArabicRTL(text)
        if (rtlText.length >= width) return rtlText.substring(0, width)
        // Since we write LTR, to align text to the right side of the paper, we want leading spaces!
        return " ".repeat(width - rtlText.length) + rtlText
    }

    fun alignLeft(text: String, width: Int): String {
        val rtlText = formatLineArabicRTL(text)
        if (rtlText.length >= width) return rtlText.substring(0, width)
        return rtlText + " ".repeat(width - rtlText.length)
    }

    // E.g., Key: "المبلغ المدفوع", Value: "150,000 د.ع" -> Value (left-aligned), Key (right-aligned)
    fun printRow(key: String, value: String, width: Int): String {
        val shapedKey = formatLineArabicRTL(key)
        val shapedValue = formatLineArabicRTL(value)
        
        val totalLength = shapedKey.length + shapedValue.length
        if (totalLength >= width) {
            // If too long, just stack or truncate
            return shapedValue + " " + shapedKey
        }
        
        val spacesCount = width - totalLength
        // Left part of LTR string is visually left on paper, right part of LTR is visually right on paper
        return shapedValue + " ".repeat(spacesCount) + shapedKey
    }

    fun printDivider(width: Int): String {
        return "-".repeat(width)
    }
    
    fun printDoubleDivider(width: Int): String {
        return "=".repeat(width)
    }
}
