package com.example.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.example.ui.viewmodel.InstallmentStatus
import java.net.URLEncoder

object WhatsAppHelper {

    /**
     * Iraqi Phone Number Parser:
     * 1. Remove all spaces or special characters.
     * 2. If starts with local Iraqi prefix (077, 078, 075, 079, etc.), remove the leading 0 and prepend 964.
     * 3. If starts with 964 or +964, clean it from + only.
     */
    fun formatIraqiPhoneNumber(phone: String): String {
        // Remove spaces, dashes, parentheses, or plus symbols
        val cleaned = phone.replace(Regex("[\\s\\-\\(\\)\\+]"), "")
        
        return when {
            cleaned.startsWith("07") && cleaned.length >= 11 -> {
                "964" + cleaned.substring(1)
            }
            cleaned.startsWith("7") && cleaned.length == 10 -> {
                "964" + cleaned
            }
            cleaned.startsWith("964") -> {
                cleaned
            }
            else -> {
                cleaned
            }
        }
    }

    /**
     * Standard Arabic Template Logic:
     * Generates message texts according to the installment state.
     */
    fun generateTemplate(status: InstallmentStatus, customerName: String, dueDate: String, amount: Double): String {
        val amountStr = String.format("%,.0f", amount)
        return when (status) {
            InstallmentStatus.NEAR -> {
                "تحية طيبة أستاذ $customerName، نود تذكيركم بأن موعد استحقاق قسطكم القادم هو يوم $dueDate، وقيمته $amountStr د.ع (نقداً). يسعدنا تشريفكم لنا في المحل لإتمام السداد، وشاكرين لكم حسن التزامكم."
            }
            InstallmentStatus.DUE -> {
                "عزيزنا العميل $customerName، نفيدكم بأن اليوم $dueDate هو الموعد المحدد لسداد قسطكم الحالي البالغ $amountStr د.ع (نقداً). نحن بانتظار زيارتكم للمحل لتسديد المبلغ وتحديث حسابكم في النظام. دمتم بخير."
            }
            InstallmentStatus.OVERDUE -> {
                "السلام عليكم أستاذ $customerName، نلفت انتباهكم إلى أن القسط المستحق بتاريخ $dueDate والبالغ $amountStr د.ع (نقداً) قد تخطى موعد سداده المحدد ولم يصلنا حتى الآن. يرجى التكرم بزيارتنا في أقرب وقت لتسوية المتأخرات تفادياً لتراكم الأقساط القادمة. شاكرين ومقدرين تفهمكم."
            }
            else -> {
                "مرحباً أستاذ $customerName، نود إعلامكم بأن القسط المستحق بتاريخ $dueDate والبالغ $amountStr د.ع (نقداً) بانتظار سدادكم في المحل. تفضلوا بزيارتنا لتسوية الحساب. شكراً لكم."
            }
        }
    }

    /**
     * Safe Intent Launcher:
     * Safely encodes the message and launches the WhatsApp intent.
     */
    fun sendWhatsAppMessage(context: Context, phone: String, status: InstallmentStatus, customerName: String, dueDate: String, amount: Double) {
        val formattedPhone = formatIraqiPhoneNumber(phone)
        val message = generateTemplate(status, customerName, dueDate, amount)
        
        try {
            val encodedMessage = URLEncoder.encode(message, "UTF-8")
            val url = "https://api.whatsapp.com/send?phone=$formattedPhone&text=$encodedMessage"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse(url)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "فشل فتح تطبيق الواتساب أو تشفير الرسالة", Toast.LENGTH_SHORT).show()
        }
    }
}
